"""
T4. Fragile Memory / Refreshing Recollection Test.

Doc's design: memory probe -> specific detail -> document refresh (a REAL
exhibit) -> post-refresh probe. Primary: Nervous, Defensive, Evasive.
Control: Cooperative, Overprepared.

The document-refresh turn is why case_prep_extractor.py insists on a real
exhibit grounded in the actual transcript rather than an invented one — a
fabricated exhibit number here would be immediately implausible to the
model and to any human reviewing the run.
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import judge_prompts as jp
import rubrics
from session_runner import fork_for_test, run_turn


def build_questions(case_prep: dict) -> list[str]:
    entity = case_prep["entity_name"]
    topic = case_prep["sensitive_topic"]["phrase"]
    exhibit = case_prep["exhibit"]
    return [
        f"Do you recall anything about {topic} during your time at {entity}?",
        "Do you recall approximately when that was?",
        f"Let me show you {exhibit['label']} — {exhibit['description']}. Does reviewing this document refresh your recollection?",
        "Now that you've reviewed it — do you recall that?",
    ]


def run(persona: dict, archetype_name: str, warmed_session: dict, case_prep: dict, client=None) -> dict:
    exhibit = case_prep.get("exhibit")
    if not exhibit or not exhibit.get("label"):
        raise ValueError(f"T4 requires a real exhibit in case_prep for {persona['name']}, none found")

    session = fork_for_test(warmed_session)
    questions = build_questions(case_prep)

    pre_fields = [f for f in rubrics.T4["fields"] if f["name"] != "post_refresh_improvement"]
    post_fields = rubrics.T4["fields"]

    turns = []
    for i, q in enumerate(questions, start=1):
        result = run_turn(session, q, client=client)
        fields = post_fields if i >= 3 else pre_fields
        extra = (
            "This is post-exhibit (score post_refresh_improvement)." if i >= 3
            else "This is pre-exhibit (post_refresh_improvement is null/N-A)."
        )
        judged = jp.judge_single_response(
            "T4", q, result["reply"], fields,
            extra_context=f"Turn {i} of 4", extra_instructions=extra, client=client,
        )
        turns.append({
            "turn": i, "question": q, "reply": result["reply"],
            "state": result["state"], "judged": judged,
        })

    return {"test": "T4", "archetype": archetype_name, "witness": persona["name"], "turns": turns}
