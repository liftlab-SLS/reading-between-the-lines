"""
T1. Evasive Pin-Down Test.

Doc's design: a 5-turn sequence narrowing from a broad open question down
to an explicit binary yes/no demand. Primary archetypes: Evasive,
Defensive, Nervous. Control: Cooperative, Neutral.

Turn 5's exact wording matters mechanically: the doc's own example ("I'm
asking for a yes or no: ...reviewing suspicious orders?") does NOT actually
end in the literal "yes or no" (it ends in "...orders?"), nor is it <= 8
words — so the real classifier would NOT tag it "closed", silently
breaking the test's own turn-5 pin-down measurement. Every narrowing/closed
question here instead ends in "correct?" (which the classifier
exact-matches including the "?"), guaranteeing the intended classification
regardless of phrase length.

Mid-deposition warm-up + fork (the general pattern) — nothing here needs a
fixed external turn reference.
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import judge_prompts as jp
import rubrics
from session_runner import fork_for_test, run_turn


def build_questions(case_prep: dict) -> list[str]:
    entity = case_prep["entity_name"]
    topic = case_prep["sensitive_topic"]["phrase"]
    return [
        f"Can you describe {entity}'s {topic}?",
        f"Who was responsible for decisions related to {topic}?",
        "Was that responsibility assigned to your department?",
        f"So during your time there, your department was responsible for matters related to {topic}, correct?",
        f"I'm asking directly — was your department responsible for {topic}, correct?",
    ]


def run(persona: dict, archetype_name: str, warmed_session: dict, case_prep: dict, client=None) -> dict:
    session = fork_for_test(warmed_session)
    questions = build_questions(case_prep)

    turn_fields = [f for f in rubrics.T1["fields"] if f["name"] != "turn5_binary_compliance"]
    turn5_field = [f for f in rubrics.T1["fields"] if f["name"] == "turn5_binary_compliance"]

    turns = []
    for i, q in enumerate(questions, start=1):
        result = run_turn(session, q, client=client)
        fields = turn_fields + (turn5_field if i == 5 else [])
        extra = "This is turn 5, the explicit binary yes/no demand — score turn5_binary_compliance." if i == 5 else ""
        judged = jp.judge_single_response(
            "T1", q, result["reply"], fields,
            extra_context=f"Turn {i} of 5", extra_instructions=extra, client=client,
        )
        turns.append({
            "turn": i, "question": q, "reply": result["reply"],
            "state": result["state"], "judged": judged,
        })

    return {"test": "T1", "archetype": archetype_name, "witness": persona["name"], "turns": turns}
