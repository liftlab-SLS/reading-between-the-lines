"""
T2. Runaway Witness / Rabbit Trail Test.

Doc's design: 4 turns — deliberately open invite, attempt to narrow, restate
constraint, explicit yes/no demand. Primary: Loquacious, Inventive, Evasive.
Control: Neutral, Cooperative.

Turn 4 ends in "correct?" for the same reason as T1 — guarantees "closed"
classification regardless of phrase length, unlike the doc's own literal
"...yes or no?" example (which doesn't satisfy the real classifier).
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import judge_prompts as jp
import rubrics
from session_runner import fork_for_test, run_turn


def build_questions(case_prep: dict) -> list[str]:
    entity = case_prep["entity_name"]
    topic = case_prep["sensitive_topic"]["phrase"]
    return [
        f"Walk me through everything you knew about {entity}'s {topic}.",
        f"I'm going to stop you there. My question is narrower: did you personally review matters related to {topic}?",
        "Please answer only that question.",
        f"Did you personally review those matters, correct?",
    ]


def run(persona: dict, archetype_name: str, warmed_session: dict, case_prep: dict, client=None) -> dict:
    session = fork_for_test(warmed_session)
    questions = build_questions(case_prep)

    turn1_field = [f for f in rubrics.T2["fields"] if f["name"] == "turn1_label"]
    compliance_field = [f for f in rubrics.T2["fields"] if f["name"] == "compliance_with_narrowing"]
    turn4_field = [f for f in rubrics.T2["fields"] if f["name"] == "turn4_binary"]

    turns = []
    for i, q in enumerate(questions, start=1):
        result = run_turn(session, q, client=client)
        if i == 1:
            fields, extra = turn1_field, "This is turn 1, the deliberately open invite — score turn1_label."
        elif i == 4:
            fields, extra = turn4_field, "This is turn 4, the explicit yes/no demand — score turn4_binary."
        else:
            fields, extra = compliance_field, f"This is turn {i}, narrowing the question — score compliance_with_narrowing."
        judged = jp.judge_single_response(
            "T2", q, result["reply"], fields,
            extra_context=f"Turn {i} of 4", extra_instructions=extra, client=client,
        )
        turns.append({
            "turn": i, "question": q, "reply": result["reply"],
            "state": result["state"], "events": result["events"], "judged": judged,
        })

    return {"test": "T2", "archetype": archetype_name, "witness": persona["name"], "turns": turns}
