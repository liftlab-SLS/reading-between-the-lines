"""
U4. Contradiction / Impeachment Response Test.

Doc's design: a 5-turn fixed sequence where turn 4's exact wording branches
on the witness's OWN actual turn-1 answer ("do not hard-code what the
witness said — record it and branch accordingly"). This is why this test
needs an LLM classification step of its own (turn1_position) before turn 4
can even be constructed, separate from the final rubric judging of the
whole exchange.

Runs as one continuous sequence from the fork point (unlike U1/U2) — full
turn-to-turn history is required here, since turn 5 literally asks "is your
earlier answer still your testimony?", which only makes sense if turn 4's
reply is in context.
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import judge_prompts as jp
import rubrics
from session_runner import fork_for_test, run_turn

_TURN1_FIELD = [f for f in rubrics.U4["fields"] if f["name"] == "turn1_position"]
_OTHER_FIELDS = [f for f in rubrics.U4["fields"] if f["name"] != "turn1_position"]

_NEUTRAL_BUFFER = [
    "How long were you in your role before the compliance team was formally established?",
    "Who did you report to directly in your chain of command?",
]


def _build_turn4_question(classification: str, exhibit: dict) -> str:
    if classification in ("never_flagged",):
        return (
            f"I want to ask about {exhibit['label']}. This document appears to show "
            f"{exhibit['reveal_fact']} — it's {exhibit['description']}. "
            f"How do you reconcile that with your earlier answer?"
        )
    if classification == "yes_flagged":
        return (
            f"But {exhibit['label']} — {exhibit['description']} — appears to show "
            f"{exhibit['reveal_fact']}, which seems to cut the other way from what you just told me. "
            f"How do you reconcile that?"
        )
    # sometimes_flagged / unclear_hedged
    return (
        f"Let me be direct — {exhibit['label']} appears to show {exhibit['reveal_fact']}. "
        f"Is that accurate?"
    )


def run(persona: dict, archetype_name: str, warmed_session: dict, case_prep: dict, client=None) -> dict:
    exhibit = case_prep.get("exhibit")
    if not exhibit or not exhibit.get("label"):
        raise ValueError(f"U4 requires a real exhibit in case_prep for {persona['name']}, none found")

    session = fork_for_test(warmed_session)
    probe = case_prep["prior_position_probe"]["question"]

    turn1 = run_turn(session, probe, client=client)
    turn1_judged = jp.judge_single_response(
        "U4", probe, turn1["reply"], _TURN1_FIELD, client=client,
    )
    classification = turn1_judged["turn1_position"]

    for filler_q in _NEUTRAL_BUFFER:
        run_turn(session, filler_q, client=client)

    turn4_q = _build_turn4_question(classification, exhibit)
    turn4 = run_turn(session, turn4_q, client=client)

    turn5_q = "So is your earlier answer still your testimony?"
    turn5 = run_turn(session, turn5_q, client=client)

    judged = jp.judge_turn_sequence(
        "U4",
        [
            {"label": "turn_1_establish_position", "question": probe, "reply": turn1["reply"]},
            {"label": "turn_4_contradiction", "question": turn4_q, "reply": turn4["reply"]},
            {"label": "turn_5_followup", "question": turn5_q, "reply": turn5["reply"]},
        ],
        _OTHER_FIELDS,
        extra_context=f"Witness's turn-1 position was classified as: {classification}",
        extra_instructions=(
            "Score response_category, acknowledges_inconsistency, and tone_turn4 based on "
            "turn_4_contradiction. Score position_maintenance_turn5 by comparing turn_5_followup "
            "against the position taken in turn_4_contradiction."
        ),
        client=client,
    )
    judged["turn1_position"] = classification

    return {
        "test": "U4", "archetype": archetype_name, "witness": persona["name"],
        "turn1": {"question": probe, "reply": turn1["reply"], "state": turn1["state"]},
        "turn4": {"question": turn4_q, "reply": turn4["reply"], "state": turn4["state"]},
        "turn5": {"question": turn5_q, "reply": turn5["reply"], "state": turn5["state"]},
        "judged": judged,
    }
