"""
U2. Sensitive Topic Matched-Pair Test.

Doc's design: 2 independent single-turn injections (sensitive vs. a
structurally-matched neutral control topic), each a COLD start — "run each
condition as a completely separate fresh deposition... you need identical
s0 starting state for both." This is the one test where the doc explicitly
overrides the general mid-deposition warm-up (unlike U1/U3/U4/T1-T5) —
here the whole point is testing the sensitivity encoding mechanism in
isolation, so any accumulated pressure would contaminate the comparison.
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import judge_prompts as jp
import rubrics
from session_runner import new_session, clone_for_parallel_injection, run_turn

CONDITIONS = ["sensitive", "neutral"]


def build_questions(case_prep: dict) -> dict:
    entity = case_prep["entity_name"]
    sensitive = case_prep["sensitive_topic"]["phrase"]
    neutral = case_prep["neutral_control_topic"]["phrase"]
    return {
        "sensitive": f"Can you describe {sensitive} at {entity} during the period you worked there?",
        "neutral": f"Can you describe {neutral} at {entity} during the period you worked there?",
    }


def run(persona: dict, archetype_name: str, archetype_state: dict, case_prep: dict, client=None) -> dict:
    """Cold start (no warm_up/fork_for_test) — see module docstring."""
    fresh = new_session(persona, archetype_state)
    questions = build_questions(case_prep)
    sessions = clone_for_parallel_injection(fresh, len(CONDITIONS))

    results = {}
    for condition, sess in zip(CONDITIONS, sessions):
        q = questions[condition]
        turn = run_turn(sess, q, client=client)
        judged = jp.judge_single_response(
            "U2", q, turn["reply"], rubrics.U2["fields"],
            extra_context=f"Condition: {condition}", client=client,
        )
        results[condition] = {
            "question": q,
            "reply": turn["reply"],
            "sensitivity": turn["encoding"]["sensitivity"],
            "K": turn["state"]["K"],
            "judged": judged,
        }

    return {"test": "U2", "archetype": archetype_name, "witness": persona["name"], "results": results}
