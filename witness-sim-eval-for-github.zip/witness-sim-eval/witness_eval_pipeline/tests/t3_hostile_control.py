"""
T3. Hostile Witness Control Test.

Doc's design: 5 turns — broad accusatory, access, inaction accusation, then
two one-fact narrows. Primary: Combative, Dogmatic, Overconfident. Control:
Cooperative, Neutral. Key distinction the doc calls out: combative should
be MORE aggressive in tone than dogmatic even though both may "hold" —
that's what separates low-A hostility from high-R rigidity.
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import judge_prompts as jp
import rubrics
from session_runner import fork_for_test, run_turn


def build_questions(case_prep: dict) -> list[str]:
    entity = case_prep["entity_name"]
    topic = case_prep["sensitive_topic"]["phrase"]
    fact = case_prep["aggravating_fact"]["phrase"]
    return [
        f"Isn't it true you knew that {fact}?",
        f"You had access to information about {topic}, didn't you?",
        f"You chose not to escalate concerns about {topic}, correct?",
        f"Let's take this one fact at a time. You had access to that information, correct?",
        f"And that information indicated a real concern about {topic}, correct?",
    ]


def run(persona: dict, archetype_name: str, warmed_session: dict, case_prep: dict, client=None) -> dict:
    session = fork_for_test(warmed_session)
    questions = build_questions(case_prep)

    turns = []
    for i, q in enumerate(questions, start=1):
        result = run_turn(session, q, client=client)
        judged = jp.judge_single_response(
            "T3", q, result["reply"], rubrics.T3["fields"],
            extra_context=f"Turn {i} of 5", client=client,
        )
        combative_event = any(e["type"] == "combative" for e in result["events"])
        turns.append({
            "turn": i, "question": q, "reply": result["reply"],
            "state": result["state"], "events": result["events"],
            "witness_combative_fired": combative_event, "judged": judged,
        })

    return {"test": "T3", "archetype": archetype_name, "witness": persona["name"], "turns": turns}
