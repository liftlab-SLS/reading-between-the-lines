"""
U3. Pressure-Recovery Arc Test.

Doc's design: one continuous 15-turn sequence in 4 blocks — Baseline(1-3) /
Pressure(4-8) / Recovery(9-12) / Re-escalation(13-15). "Do not break it into
pieces — the whole point is to measure cumulative effects across blocks."

Starts from a mid-deposition warm-up + fork (the general pattern), since
nothing about this test's own turn-1-15 numbering needs to align to a fixed
external reference the way T6's fatigue term does — the block comparisons
are all relative to each other within this one run.

Pressure-block and re-escalation questions are built from case_prep's
aggravating_fact/sensitive_topic rather than the doc's Mallinckrodt-specific
wording (distribution volumes, a 2009 Florida diversion date, a sales-bonus
detail) — generalized to whatever this witness's own record supports.
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import judge_prompts as jp
import rubrics
from session_runner import fork_for_test, run_turn

_BLOCKS = (
    [("BL", i) for i in range(1, 4)]
    + [("PR", i) for i in range(4, 9)]
    + [("RC", i) for i in range(9, 13)]
    + [("RE", i) for i in range(13, 16)]
)


def build_questions(case_prep: dict) -> list[str]:
    entity = case_prep["entity_name"]
    topic = case_prep["sensitive_topic"]["phrase"]
    fact = case_prep["aggravating_fact"]["phrase"]

    baseline = [
        f"What year did you first join {entity}?",
        "What department did you work in when you first started?",
        "How many direct reports did you have in your role?",
    ]
    pressure = [
        f"Isn't it true you knew that {fact}?",
        f"You had access to information about {topic}, didn't you?",
        f"{entity} was aware of concerns related to {topic} during your tenure — you knew that, didn't you?",
        f"Isn't it a fact that you never once formally raised a concern about {topic} despite what you knew?",
        f"Your compensation was tied to performance metrics, wasn't it? So you had an incentive to overlook concerns about {topic}.",
    ]
    recovery = [
        "What time did you usually arrive at the office?",
        "Who else worked in your department?",
        "What was your typical daily routine?",
        "Did you work primarily out of one office location?",
    ]
    re_escalation = [
        f"Let's go back to {topic}. Isn't it true that was flagged internally as a concern?",
        "You reviewed those concerns yourself, didn't you?",
        "And yet you took no action. Is that your testimony?",
    ]
    return baseline + pressure + recovery + re_escalation


def run(persona: dict, archetype_name: str, warmed_session: dict, case_prep: dict, client=None) -> dict:
    session = fork_for_test(warmed_session)
    questions = build_questions(case_prep)

    turns = []
    for (block, turn_num), q in zip(_BLOCKS, questions):
        result = run_turn(session, q, client=client)
        judged = jp.judge_single_response(
            "U3", q, result["reply"], rubrics.U3["fields"],
            extra_context=f"Block: {block} (turn {turn_num} of 15)", client=client,
        )
        turns.append({
            "turn": turn_num, "block": block, "question": q, "reply": result["reply"],
            "state": result["state"], "events": result["events"], "judged": judged,
        })

    block_means = {}
    for block in ("BL", "PR", "RC", "RE"):
        block_turns = [t for t in turns if t["block"] == block]
        block_means[block] = {
            "mean_C": sum(t["state"]["C"] for t in block_turns) / len(block_turns),
            "mean_hedge": sum(t["judged"]["hedge_count"] for t in block_turns) / len(block_turns),
            "mean_direct_answer": sum(t["judged"]["direct_answer"] for t in block_turns) / len(block_turns),
            "mean_tone": sum(t["judged"]["tone"] for t in block_turns) / len(block_turns),
            "rattled_events": sum(
                1 for t in block_turns for e in t["events"] if e["type"] == "intimidation"
            ),
        }

    return {
        "test": "U3", "archetype": archetype_name, "witness": persona["name"],
        "turns": turns, "block_means": block_means,
    }
