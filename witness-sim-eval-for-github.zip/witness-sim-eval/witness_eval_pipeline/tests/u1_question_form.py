"""
U1. Question Form Battery.

Doc's design: 5 independent single-turn injections (open / closed yes-no /
leading / high-pressure / clarifying), all from an IDENTICAL starting state
— "do not run them sequentially in the same deposition."

Question wording is adapted from the doc's Mallinckrodt-specific examples,
generalized via case_prep's entity_name/sensitive_topic/aggravating_fact,
and corrected against the REAL classifier logic in state_engine.py:43-51
(the doc's own example leading question, "You would agree...", does NOT
actually start with the exact prefix the classifier checks for —
"would you agree" — so it would silently misclassify. Every template here
is worded to land in its intended question_type/pressure bucket against the
real, exact-match classifier, not the doc's prose description of it.
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import judge_prompts as jp
import rubrics
from session_runner import fork_for_test, clone_for_parallel_injection, run_turn

CONDITIONS = ["open", "closed", "leading", "high_pressure", "clarifying"]


def build_questions(case_prep: dict) -> dict:
    entity = case_prep["entity_name"]
    topic = case_prep["sensitive_topic"]["phrase"]
    fact = case_prep["aggravating_fact"]["phrase"]

    return {
        "open": f"Can you walk me through what you knew about {topic} during your time at {entity}?",
        # Ends in "correct?" so it lands as "closed" regardless of length/phrasing of `topic`.
        "closed": f"You were aware of {topic}, correct?",
        # Must start with the exact literal "would you agree" for the real classifier to tag it "leading".
        "leading": f"Would you agree that {fact}?",
        # Starts with "isn't it true" (a leading-prefix AND a pressure marker) + "you knew" (another
        # pressure marker) -> still classified "leading" like the plain leading condition, but with
        # meaningfully higher `pressure` — matches the doc's own intent (verify p_t is higher here).
        "high_pressure": f"Isn't it true you knew that {fact}?",
        "clarifying": (
            f"When you say you were 'generally aware' of {topic} — "
            f"what specific information did you actually have access to?"
        ),
    }


def run(persona: dict, archetype_name: str, warmed_session: dict, case_prep: dict, client=None) -> dict:
    """Run all 5 U1 variants for one archetype from an identical forked state."""
    forked = fork_for_test(warmed_session)
    questions = build_questions(case_prep)
    sessions = clone_for_parallel_injection(forked, len(CONDITIONS))

    results = {}
    for condition, sess in zip(CONDITIONS, sessions):
        q = questions[condition]
        turn = run_turn(sess, q, client=client)

        extra = (
            "" if condition in ("leading", "high_pressure")
            else "This condition is NOT leading/high-pressure, so framing_acceptance must be null."
        )
        judged = jp.judge_single_response(
            "U1", q, turn["reply"], rubrics.U1["fields"],
            extra_context=f"Question condition: {condition}",
            extra_instructions=extra, client=client,
        )

        results[condition] = {
            "question": q,
            "reply": turn["reply"],
            "word_count": len(turn["reply"].split()),
            "pressure": turn["encoding"]["pressure"],
            "question_type": turn["encoding"]["question_type"],
            "state": turn["state"],
            "judged": judged,
        }

    return {"test": "U1", "archetype": archetype_name, "witness": persona["name"], "results": results}
