"""
T6. Overprepared / Fatigue Degradation Test.

Doc's design: a 30-turn moderate-pressure deposition with rotating filler
questions, where the SAME extraction question is asked verbatim at turns
5, 15, and 25 — only those three turns are scored. Primary: Overprepared.
Control: Neutral, Cooperative.

Must be COLD START (turn=0), unlike most other tests here: the fatigue
term phi_t = min(1, t/20) is explicitly turn-dependent, so forking from an
already-warmed session (nonzero turn counter) would shift turns 5/15/25 to
a different point on the fatigue curve than the doc's design intends.
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import judge_prompts as jp
import rubrics
from session_runner import new_session, run_turn

_EXTRACTION_TURNS = (5, 15, 25)


def build_questions(case_prep: dict) -> tuple[list[str], str]:
    entity = case_prep["entity_name"]
    topic = case_prep["sensitive_topic"]["phrase"]

    extraction_q = f"In your own words, what was {entity}'s responsibility regarding {topic}?"
    filler_bank = [
        f"Can you explain {entity}'s rationale for decisions related to {topic}?",
        "What was your understanding of the company's regulatory obligations in this area?",
        "Walk me through how decisions in your department were typically made.",
        f"What did you know about {entity}'s position in the market during that period?",
        f"Describe your role in {entity}'s response to concerns about {topic}.",
    ]

    questions = []
    filler_idx = 0
    for turn in range(1, 31):
        if turn in _EXTRACTION_TURNS:
            questions.append(extraction_q)
        else:
            questions.append(filler_bank[filler_idx % len(filler_bank)])
            filler_idx += 1
    return questions, extraction_q


def run(persona: dict, archetype_name: str, archetype_state: dict, case_prep: dict, client=None) -> dict:
    """Cold start (no warm_up/fork_for_test) — see module docstring."""
    session = new_session(persona, archetype_state)
    questions, extraction_q = build_questions(case_prep)

    scored_turns = {}
    turn5_reply = None
    for turn_num, q in enumerate(questions, start=1):
        result = run_turn(session, q, client=client)
        if turn_num not in _EXTRACTION_TURNS:
            continue

        if turn_num == 5:
            fields = [f for f in rubrics.T6["fields"] if f["name"] != "consistency_with_turn5"]
            extra_context = "This is the FIRST extraction point (turn 5) — no prior extraction turn to compare against."
            extra_instructions = "consistency_with_turn5 is null/N-A for this turn."
            turn5_reply = result["reply"]
        else:
            fields = rubrics.T6["fields"]
            extra_context = (
                f"This is extraction turn {turn_num}. The SAME extraction question was asked at turn 5, "
                f"where the witness answered:\n\"{turn5_reply}\"\n\nCompare the current reply against that "
                f"turn-5 answer for consistency_with_turn5."
            )
            extra_instructions = ""

        judged = jp.judge_single_response(
            "T6", q, result["reply"], fields,
            extra_context=extra_context, extra_instructions=extra_instructions, client=client,
        )
        scored_turns[turn_num] = {
            "turn": turn_num, "question": q, "reply": result["reply"],
            "state": result["state"], "P": result["state"]["P"],
            "phi_t": min(1.0, turn_num / 20.0), "judged": judged,
        }

    return {"test": "T6", "archetype": archetype_name, "witness": persona["name"], "extraction_turns": scored_turns}
