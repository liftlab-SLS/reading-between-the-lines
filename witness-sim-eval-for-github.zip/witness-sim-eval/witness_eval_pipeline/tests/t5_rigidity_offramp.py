"""
T5. Rigidity Under Friendly Off-Ramp Test.

Doc's design: establish position -> 2-turn neutral buffer -> a friendly,
explicitly LOW-PRESSURE off-ramp -> confirmation. Primary: Dogmatic,
Overconfident, Combative. Control: Cooperative, Nervous. Critical design
note from the doc: turn 4 must have low p_t — verified here directly from
the real encoding (no pressure markers in the wording), not assumed.
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import judge_prompts as jp
import rubrics
from session_runner import fork_for_test, run_turn

_OFF_RAMP = (
    "I want to make sure I understand your earlier answer correctly. Is it possible that "
    "went to someone else, or through a different process, and it just didn't reach you? "
    "There's really no pressure either way — I just want to make sure we have an accurate record."
)


def build_questions(case_prep: dict) -> list[str]:
    entity = case_prep["entity_name"]
    topic = case_prep["sensitive_topic"]["phrase"]
    return [
        f"To your knowledge, did {entity} ever receive any formal complaints or concerns raised about {topic}?",
        "How long were you in your role during that period?",
        "How frequently did your department interact with the compliance function generally?",
        _OFF_RAMP,
        "So just to confirm — is your earlier answer still your testimony?",
    ]


def run(persona: dict, archetype_name: str, warmed_session: dict, case_prep: dict, client=None) -> dict:
    session = fork_for_test(warmed_session)
    questions = build_questions(case_prep)

    turn1_field = [f for f in rubrics.T5["fields"] if f["name"] == "turn1_position"]
    turn4_fields = [f for f in rubrics.T5["fields"] if f["name"] in ("turn4_classification", "tone_of_holding")]
    turn5_field = [f for f in rubrics.T5["fields"] if f["name"] == "turn5_final_position"]

    turns = []
    for i, q in enumerate(questions, start=1):
        result = run_turn(session, q, client=client)
        if i == 1:
            fields, extra = turn1_field, "Turn 1 — establish position."
        elif i == 4:
            fields, extra = turn4_fields, (
                f"Turn 4, the friendly off-ramp. Verified pressure at this turn: "
                f"{result['encoding']['pressure']:.2f} (should be low, <0.3)."
            )
        elif i == 5:
            fields, extra = turn5_field, "Turn 5 — final position, compare against turn 4."
        else:
            fields, extra = [], "Neutral buffer turn, no scoring needed."
        judged = (
            jp.judge_single_response("T5", q, result["reply"], fields, extra_instructions=extra, client=client)
            if fields else {}
        )
        turns.append({
            "turn": i, "question": q, "reply": result["reply"],
            "state": result["state"], "pressure": result["encoding"]["pressure"], "judged": judged,
        })

    return {"test": "T5", "archetype": archetype_name, "witness": persona["name"], "turns": turns}
