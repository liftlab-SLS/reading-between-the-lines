"""
LLM-as-judge scoring, built directly on the proven pattern already in this
codebase (analyze_depositions.ipynb's FUNNEL_SYSTEM + classify_funnel_stages):
explicit rubric definitions + a strict JSON-only output contract + JSON
extraction that tolerates a bit of prose around it.

Two shapes, matching what the doc's tests actually need:
  - judge_single_response: score ONE witness reply against a rubric's
    fields (used by U1's 5 independent variants, U2's 2 variants, and
    most per-turn annotation in T1-T3/T5).
  - judge_turn_sequence: score a short SEQUENCE of turns together, where
    later turns need earlier ones as context (U4's turn-4 response
    category needs turn 1's actual answer; T6's consistency check needs
    turn 5 as a reference point).
"""

import json
import re

from dotenv import load_dotenv
from pathlib import Path

load_dotenv(Path(__file__).resolve().parent.parent / ".env")

import anthropic

from llm_utils import response_text

JUDGE_MODEL = "claude-sonnet-5"

_client = None


def get_client() -> anthropic.Anthropic:
    global _client
    if _client is None:
        _client = anthropic.Anthropic()
    return _client


def _describe_field(field: dict) -> str:
    """Render one rubric field's definition as prompt text."""
    lines = [f"- \"{field['name']}\" ({field['type']}"
             + (f", {field['min']}-{field['max']}" if field["type"] == "scale" else "") + ")"]
    if field["type"] == "scale":
        for level, desc in sorted(field["levels"].items(), reverse=True):
            lines.append(f"    {level} = {desc}")
        if field.get("na_if"):
            lines.append(f"    Use null if: {field['na_if']}")
    elif field["type"] == "label_set":
        labels = field["labels"]
        if isinstance(labels, dict):
            for label, desc in labels.items():
                lines.append(f"    {label}: {desc}")
            if field.get("single_select"):
                lines.append("    Choose exactly ONE label.")
        else:
            lines.append(f"    One of: {', '.join(labels)}")
    elif field["type"] in ("count", "list"):
        if field.get("note"):
            lines.append(f"    {field['note']}")
    return "\n".join(lines)


def _fields_json_shape(fields: list[dict]) -> str:
    parts = []
    for f in fields:
        if f["type"] == "scale":
            parts.append(f'"{f["name"]}": <integer {f["min"]}-{f["max"]}, or null>')
        elif f["type"] == "count":
            parts.append(f'"{f["name"]}": <integer count>')
        elif f["type"] == "label_set" and f.get("multi_select"):
            parts.append(f'"{f["name"]}": <array of applicable labels>')
        elif f["type"] == "label_set":
            parts.append(f'"{f["name"]}": <one label string>')
        elif f["type"] == "list":
            parts.append(f'"{f["name"]}": <array of strings, empty array if none>')
        else:
            parts.append(f'"{f["name"]}": <value>')
    return "{\n  " + ",\n  ".join(parts) + "\n}"


def build_rubric_system_prompt(test_name: str, fields: list[dict], extra_instructions: str = "") -> str:
    field_defs = "\n".join(_describe_field(f) for f in fields)
    json_shape = _fields_json_shape(fields)
    return f"""You are a legal deposition analyst scoring a witness's response(s) for the \
evaluation test "{test_name}". Score using ONLY the definitions below — judge the underlying \
function/pattern being described, not surface string-matching against any example phrases given.

FIELDS TO SCORE:
{field_defs}

{extra_instructions}

Return ONLY valid JSON in exactly this shape, no markdown fences, no commentary:
{json_shape}
"""


def _extract_json(raw: str) -> dict:
    match = re.search(r"\{.*\}", raw, re.DOTALL)
    if not match:
        raise ValueError(f"judge: no JSON found in response: {raw[:500]}")
    return json.loads(match.group())


def judge_single_response(test_name: str, question: str, reply: str, fields: list[dict],
                           extra_context: str = "", extra_instructions: str = "",
                           client: anthropic.Anthropic | None = None, model: str = JUDGE_MODEL) -> dict:
    """Score one witness reply (in response to one question) against a rubric's fields."""
    client = client or get_client()
    system = build_rubric_system_prompt(test_name, fields, extra_instructions)
    user = (
        (f"{extra_context}\n\n" if extra_context else "")
        + f"ATTORNEY QUESTION:\n{question}\n\nWITNESS REPLY:\n{reply}\n"
    )
    response = client.messages.create(
        model=model, max_tokens=1024, system=system,
        thinking={"type": "disabled"},
        messages=[{"role": "user", "content": user}],
    )
    return _extract_json(response_text(response).strip())


def judge_turn_sequence(test_name: str, turns: list[dict], fields: list[dict],
                         extra_context: str = "", extra_instructions: str = "",
                         client: anthropic.Anthropic | None = None, model: str = JUDGE_MODEL) -> dict:
    """
    Score a short sequence of {question, reply, label} turns together, where
    the judge needs cross-turn context (e.g. "does turn 4 acknowledge turn
    1's answer?"). `turns[i]["label"]` (e.g. "turn_1", "turn_4") lets the
    system prompt refer to specific turns by name in extra_instructions.
    """
    client = client or get_client()
    system = build_rubric_system_prompt(test_name, fields, extra_instructions)
    turn_text = "\n\n".join(
        f"[{t.get('label', f'turn_{i+1}')}]\nQUESTION: {t['question']}\nREPLY: {t['reply']}"
        for i, t in enumerate(turns)
    )
    user = (f"{extra_context}\n\n" if extra_context else "") + turn_text
    response = client.messages.create(
        model=model, max_tokens=1536, system=system,
        thinking={"type": "disabled"},
        messages=[{"role": "user", "content": user}],
    )
    return _extract_json(response_text(response).strip())
