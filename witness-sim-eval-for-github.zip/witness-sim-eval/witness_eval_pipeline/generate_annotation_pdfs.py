#!/usr/bin/env python3
"""
Generate one self-contained PDF per (witness, test) — the actual generated
transcript to be scored, the exact scoring instructions given to the LLM
judge (same rubric text, for a fair human-vs-LLM comparison), and a blank
scoring template. Organized by witness, then test:

    human_annotation/<witness>_<doc_id>/U1.pdf
    human_annotation/<witness>_<doc_id>/U4.pdf
    ...

Does NOT include the LLM judge's own scores — the human should score blind,
to be compared against the LLM afterward.
"""

import json
import re
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

import rubrics
from judge_prompts import _describe_field

from reportlab.lib.pagesizes import letter
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch
from reportlab.lib.enums import TA_LEFT
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, HRFlowable, KeepTogether
from reportlab.lib import colors

RESULTS_DIR = Path("/Users/divya/witness-sim-eval/sample_300/batch_results")
OUT_DIR = Path("/Users/divya/witness-sim-eval/sample_300/human_annotation")

styles = getSampleStyleSheet()
title_style = ParagraphStyle("TitleX", parent=styles["Title"], fontSize=16, spaceAfter=4)
meta_style = ParagraphStyle("Meta", parent=styles["Normal"], fontSize=9, textColor=colors.grey, spaceAfter=12)
h2_style = ParagraphStyle("H2", parent=styles["Heading2"], fontSize=13, spaceBefore=14, spaceAfter=6,
                          textColor=colors.HexColor("#1F4E78"))
h3_style = ParagraphStyle("H3", parent=styles["Heading3"], fontSize=11, spaceBefore=10, spaceAfter=4)
body_style = ParagraphStyle("BodyX", parent=styles["Normal"], fontSize=10, leading=14, alignment=TA_LEFT)
q_style = ParagraphStyle("Q", parent=body_style, textColor=colors.HexColor("#8A5300"), spaceBefore=6)
a_style = ParagraphStyle("A", parent=body_style, spaceBefore=2, spaceAfter=8)
instr_style = ParagraphStyle("Instr", parent=body_style, fontSize=9, leftIndent=12,
                              textColor=colors.HexColor("#333333"))
blank_style = ParagraphStyle("Blank", parent=body_style, fontSize=10, spaceBefore=4, spaceAfter=10)


def esc(text: str) -> str:
    """Escape for reportlab's mini-HTML paragraph markup, preserve newlines as breaks."""
    if text is None:
        return ""
    text = str(text).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
    return text.replace("\n", "<br/>")


def rubric_instructions_flowables(fields: list[dict]) -> list:
    flows = []
    for f in fields:
        desc = _describe_field(f)
        flows.append(Paragraph(esc(desc).replace("\n", "<br/>"), instr_style))
    return flows


def scoring_blank_flowables(fields: list[dict], label_prefix: str = "") -> list:
    flows = []
    for f in fields:
        name = f["name"]
        if f["type"] == "scale":
            hint = f"(integer {f['min']}-{f['max']}, or N/A)"
        elif f["type"] == "count":
            hint = "(integer count)"
        elif f["type"] == "label_set" and f.get("multi_select"):
            hint = "(check all that apply)"
        elif f["type"] == "label_set":
            labels = f["labels"]
            options = ", ".join(labels.keys()) if isinstance(labels, dict) else ", ".join(labels)
            hint = f"(one of: {options})"
        else:
            hint = ""
        flows.append(Paragraph(f"<b>{label_prefix}{name}</b> {hint}: ______________________________", blank_style))
    return flows


def build_pdf(out_path: Path, witness_name: str, doc_id: str, archetype: str, collection: str,
              test_code: str, test_meta: dict, content_flowables: list):
    doc = SimpleDocTemplate(str(out_path), pagesize=letter,
                             topMargin=0.75 * inch, bottomMargin=0.75 * inch,
                             leftMargin=0.85 * inch, rightMargin=0.85 * inch)
    flows = []
    flows.append(Paragraph(esc(f"{witness_name} — {test_code}: {test_meta['name'].split('. ', 1)[-1]}"), title_style))
    flows.append(Paragraph(
        esc(f"Archetype: {archetype}  |  Source document: {doc_id}  |  Collection: {collection}"),
        meta_style,
    ))
    flows.append(HRFlowable(width="100%", thickness=1, color=colors.HexColor("#CCCCCC")))

    flows.append(Paragraph("WHAT THIS TEST IS FOR", h2_style))
    flows.append(Paragraph(esc(test_meta.get("scope", "")), body_style))

    flows.append(Paragraph("SCORING INSTRUCTIONS", h2_style))
    flows.append(Paragraph(
        "These are the exact field definitions given to the LLM judge for this test. "
        "Score using these definitions only — judge the underlying pattern being described, "
        "not surface string-matching against any example phrases given.", body_style,
    ))
    flows.extend(rubric_instructions_flowables(test_meta["fields"]))

    flows.append(Paragraph("TRANSCRIPT TO SCORE", h2_style))
    flows.append(Paragraph(
        "Fill in your own score for each field directly below the exchange it applies to, "
        "independent of any other scoring.", body_style,
    ))
    flows.extend(content_flowables)

    doc.build(flows)


def build_u1(witness_name, doc_id, archetype, collection, result):
    fields = rubrics.U1["fields"]
    content = []
    label_map = {"open": "OPEN", "closed": "CLOSED YES/NO", "leading": "LEADING",
                 "high_pressure": "HIGH PRESSURE", "clarifying": "CLARIFYING"}
    for cond in ["open", "closed", "leading", "high_pressure", "clarifying"]:
        r = result["results"][cond]
        content.append(Paragraph(f"Condition: {label_map[cond]}", h3_style))
        content.append(Paragraph(f"<b>Q:</b> {esc(r['question'])}", q_style))
        content.append(Paragraph(f"<b>A:</b> {esc(r['reply'])}", a_style))
        na_note = "" if cond in ("leading", "high_pressure") else " (framing_acceptance = N/A for this condition)"
        content.extend(scoring_blank_flowables(fields, label_prefix=""))
        if na_note:
            content.append(Paragraph(f"<i>{na_note.strip()}</i>", instr_style))
        content.append(Spacer(1, 8))
    out_dir = OUT_DIR / f"{sanitize(witness_name)}_{doc_id}"
    out_dir.mkdir(parents=True, exist_ok=True)
    build_pdf(out_dir / "U1.pdf", witness_name, doc_id, archetype, collection, "U1", rubrics.U1, content)


def build_u4(witness_name, doc_id, archetype, collection, result):
    fields = rubrics.U4["fields"]
    content = []
    for label, key in [("Turn 1 — Establish Position", "turn1"),
                        ("Turn 4 — Contradiction", "turn4"),
                        ("Turn 5 — Follow-up", "turn5")]:
        r = result[key]
        content.append(Paragraph(label, h3_style))
        content.append(Paragraph(f"<b>Q:</b> {esc(r['question'])}", q_style))
        content.append(Paragraph(f"<b>A:</b> {esc(r['reply'])}", a_style))
    content.append(Paragraph("Score the exchange as a whole:", h3_style))
    content.extend(scoring_blank_flowables(fields))
    out_dir = OUT_DIR / f"{sanitize(witness_name)}_{doc_id}"
    out_dir.mkdir(parents=True, exist_ok=True)
    build_pdf(out_dir / "U4.pdf", witness_name, doc_id, archetype, collection, "U4", rubrics.U4, content)


def build_turn_sequence(witness_name, doc_id, archetype, collection, result, test_key,
                         per_turn_fields_fn, out_name):
    content = []
    for t in result["turns"]:
        n = t["turn"]
        content.append(Paragraph(f"Turn {n}", h3_style))
        content.append(Paragraph(f"<b>Q:</b> {esc(t['question'])}", q_style))
        content.append(Paragraph(f"<b>A:</b> {esc(t['reply'])}", a_style))
        fields = per_turn_fields_fn(n)
        if fields:
            content.extend(scoring_blank_flowables(fields))
        content.append(Spacer(1, 6))
    out_dir = OUT_DIR / f"{sanitize(witness_name)}_{doc_id}"
    out_dir.mkdir(parents=True, exist_ok=True)
    build_pdf(out_dir / f"{out_name}.pdf", witness_name, doc_id, archetype, collection, out_name,
              rubrics.ALL_TESTS[out_name], content)


def sanitize(name: str) -> str:
    return re.sub(r"[^A-Za-z0-9]+", "_", name).strip("_")[:60]


def main():
    files = sorted(RESULTS_DIR.glob("*.json"))
    files = [f for f in files if not f.name.endswith("_FAILED.json")]
    print(f"Found {len(files)} witness result files")

    OUT_DIR.mkdir(parents=True, exist_ok=True)

    for fp in files:
        d = json.loads(fp.read_text())
        doc_id = d["id"]
        witness_name = d["witness_name"]
        collection = d["collection"]

        # U1
        r = d["results"].get("U1")
        if r and "error" not in r:
            build_u1(witness_name, doc_id, r["archetype"], collection, r)

        # U4
        r = d["results"].get("U4")
        if r and "error" not in r:
            build_u4(witness_name, doc_id, r["archetype"], collection, r)

        # T1: per-turn fields; turn5 also gets turn5_binary_compliance
        r = d["results"].get("T1")
        if r and "error" not in r:
            base_fields = [f for f in rubrics.T1["fields"] if f["name"] != "turn5_binary_compliance"]
            turn5_field = [f for f in rubrics.T1["fields"] if f["name"] == "turn5_binary_compliance"]
            build_turn_sequence(
                witness_name, doc_id, r["archetype"], collection, r, "T1",
                lambda n: base_fields + (turn5_field if n == 5 else []), "T1",
            )

        # T2: turn1_label (turn1), compliance_with_narrowing (turns 2-3), turn4_binary (turn4)
        r = d["results"].get("T2")
        if r and "error" not in r:
            f_by_name = {f["name"]: f for f in rubrics.T2["fields"]}

            def t2_fields(n, f_by_name=f_by_name):
                if n == 1:
                    return [f_by_name["turn1_label"]]
                if n == 4:
                    return [f_by_name["turn4_binary"]]
                return [f_by_name["compliance_with_narrowing"]]

            build_turn_sequence(witness_name, doc_id, r["archetype"], collection, r, "T2", t2_fields, "T2")

        # T3: labels + tone, every turn
        r = d["results"].get("T3")
        if r and "error" not in r:
            build_turn_sequence(
                witness_name, doc_id, r["archetype"], collection, r, "T3",
                lambda n: rubrics.T3["fields"], "T3",
            )

        print(f"  {witness_name!r} ({doc_id}) done")

    print(f"\nWrote annotation PDFs to {OUT_DIR}")


if __name__ == "__main__":
    main()
