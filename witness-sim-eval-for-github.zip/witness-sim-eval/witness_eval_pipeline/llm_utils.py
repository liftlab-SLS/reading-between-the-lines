"""Small shared helper for Claude API responses."""


def response_text(response) -> str:
    """
    Return the text content of a Claude response, skipping any leading
    ThinkingBlock (extended-thinking models like claude-sonnet-5 return
    thinking blocks ahead of the actual text block).
    """
    for block in response.content:
        if getattr(block, "type", None) == "text":
            return block.text
    raise ValueError(f"no text block in response content: {response.content!r}")
