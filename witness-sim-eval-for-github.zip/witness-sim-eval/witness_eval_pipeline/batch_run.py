#!/usr/bin/env python3
"""
Batch driver: run a fixed set of tests across many real witnesses,
concurrently, with per-witness checkpointing (a completed witness's JSON
is written to disk immediately, so a crash partway through doesn't lose
prior work and a re-run skips anything already done).

    python batch_run.py sample50.csv --out batch_results/

Reads a CSV with the same columns as opioids_deposition_transcripts_index.csv
(Collection, Title, ID, Transcript_File, ...) and a --transcripts-root
pointing at the folder those Transcript_File paths are relative to.
"""

import argparse
import csv
import json
import sys
import traceback
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

import anthropic

from case_prep_extractor import extract_case_prep
from persona import build_persona
from session_runner import ARCHETYPES, warm_up
from supplementary_docs import get_doc_metadata, build_doc_context, build_case_background_context
from transcript_ingest import ingest_transcript

SUPP_DOCS_MAX = 5

from tests import u1_question_form, u4_contradiction, t1_evasive_pindown, t2_runaway_witness, t3_hostile_control

# (test_name, module, kind, archetype_name) — this batch's fixed config:
# each test's own primary archetype from the doc, one per test (not the
# full primary/control set) to keep this batch's cost bounded. All five are
# "warm" tests (mid-deposition state via a real-transcript warm-up).
TESTS_CONFIG = [
    ("U1", u1_question_form, "warm", "Cooperative"),
    ("U4", u4_contradiction, "warm", "Cooperative"),
    ("T1", t1_evasive_pindown, "warm", "Evasive"),
    ("T2", t2_runaway_witness, "warm", "Loquacious"),
    ("T3", t3_hostile_control, "warm", "Combative"),
]

WARMUP_N = 10
_FRESHNESS_FIELDS = ["sensitive_topic", "aggravating_fact", "exhibit", "prior_position_probe"]


def select_warmup_questions(turns, case_prep, attorney_name, n=WARMUP_N):
    cutoffs = [
        case_prep[f]["first_turn_index"] for f in _FRESHNESS_FIELDS
        if case_prep.get(f) and case_prep[f].get("first_turn_index") is not None
    ]
    cutoff = min(cutoffs) if cutoffs else 10**9
    candidates = [
        t for t in turns
        if t["role"] == "attorney" and (attorney_name is None or t["attorney"] == attorney_name)
        and t["turn_index"] < cutoff
    ]
    return [t["text"] for t in candidates[:n]]


def process_witness(row: dict, transcripts_root: Path, out_dir: Path) -> dict:
    doc_id = row["ID"]
    out_path = out_dir / f"{doc_id}.json"
    if out_path.exists():
        return {"id": doc_id, "status": "skipped_cached"}

    client = anthropic.Anthropic()
    transcript_path = transcripts_root / row["Transcript_File"]

    try:
        ingested = ingest_transcript(transcript_path)
        # extract_witness_name() looks for deposition-style captions ("DEPOSITION OF
        # X", "X, having been first duly sworn") and won't find a name in a
        # multi-day TRIAL transcript continuation fragment, where the witness was
        # only named on an earlier day's file. Falling back to the document Title
        # in that case would hand the persona its own court-filing title as its
        # "name" (seen on mzlh0257, a Day-10 trial continuation) — worse than
        # admitting uncertainty, since direct-address patterns in trial transcripts
        # ("Mr. Geldhof," "Ms. Martin,") are just as likely to be OTHER counsel in
        # the room as the actual witness. Use a clearly-flagged placeholder instead
        # so these cases are visible and excludable, not silently mislabeled.
        witness_name_uncertain = ingested["witness_name"] is None
        witness_name = ingested["witness_name"] or f"Unknown Witness ({doc_id})"

        case_prep = extract_case_prep(
            witness_name, ingested["turns"], attorney_name=ingested["attorney_name"], client=client,
        )

        # Fetch real supplementary case material (emails, memos, exhibits) for this
        # witness from UCSF's full-text index, scoped to the same specific case (not
        # just the broader collection, which can span multiple lawsuits) — populates
        # batch_sim.py's doc_context persona-enrichment param, which existed already
        # but was never fed anything real. Prioritizes documents tied to the SPECIFIC
        # subject matter this witness testified about (case_prep's sensitive_topic/
        # aggravating_fact), not just any document mentioning them. When the witness's
        # own name is uncertain (can't search BY them), falls back to general
        # case-level background material (complaint, case summary, fact sheet)
        # instead of skipping enrichment entirely — we still know the case even
        # when we don't know exactly who's speaking.
        doc_meta = get_doc_metadata(doc_id)
        if not witness_name_uncertain:
            topic_terms = [
                case_prep.get("sensitive_topic", {}).get("phrase"),
                case_prep.get("aggravating_fact", {}).get("phrase"),
            ]
            doc_context, supp_docs_fetched = build_doc_context(
                witness_name, doc_id, doc_meta.get("collectioncode"),
                case_name=doc_meta.get("case"), topic_terms=topic_terms, max_docs=SUPP_DOCS_MAX,
            )
        else:
            doc_context, supp_docs_fetched = build_case_background_context(
                doc_id, doc_meta.get("collectioncode"), case_name=doc_meta.get("case"), max_docs=SUPP_DOCS_MAX,
            )

        attorney_turns_all = [
            t for t in ingested["turns"]
            if t["role"] == "attorney" and t["attorney"] == ingested["attorney_name"]
        ]
        persona = build_persona(
            witness_name, [t["text"] for t in attorney_turns_all],
            attorney=ingested["attorney_name"], doc_context=doc_context, case_prep=case_prep, client=client,
        )

        warmup_questions = select_warmup_questions(ingested["turns"], case_prep, ingested["attorney_name"])

        results = {}
        warmed_cache: dict = {}
        for test_name, mod, kind, archetype_name in TESTS_CONFIG:
            archetype_state = ARCHETYPES[archetype_name]
            try:
                if kind == "warm":
                    if archetype_name not in warmed_cache:
                        warmed_cache[archetype_name] = warm_up(persona, archetype_state, warmup_questions, client=client)
                    state_arg = warmed_cache[archetype_name]
                else:
                    state_arg = archetype_state
                results[test_name] = mod.run(persona, archetype_name, state_arg, case_prep, client=client)
            except Exception as e:
                # e.g. U4 without a real exhibit in case_prep — skip that test for
                # this witness, keep going, log it plainly rather than silently dropping it.
                results[test_name] = {"error": f"{type(e).__name__}: {e}"}

        out = {
            "id": doc_id,
            "title": row["Title"],
            "collection": row["Collection"],
            "witness_name": witness_name,
            "witness_name_uncertain": witness_name_uncertain,
            "attorney_name": ingested["attorney_name"],
            "supplementary_docs_fetched": supp_docs_fetched,
            "case_prep": {k: v for k, v in case_prep.items() if not k.startswith("_")},
            "results": results,
        }
        out_path.write_text(json.dumps(out, indent=2, default=str))
        n_errors = sum(1 for r in results.values() if isinstance(r, dict) and "error" in r)
        return {
            "id": doc_id, "status": "ok", "test_errors": n_errors,
            "witness_name_uncertain": witness_name_uncertain,
            "n_supp_docs": len(supp_docs_fetched),
        }

    except Exception as e:
        err = {"id": doc_id, "status": "error", "error": str(e), "traceback": traceback.format_exc()}
        (out_dir / f"{doc_id}_FAILED.json").write_text(json.dumps(err, indent=2))
        return err


def main(csv_path: str, transcripts_root: str, out_dir: str, max_workers: int):
    rows = list(csv.DictReader(open(csv_path, newline="", encoding="utf-8")))
    out_path_dir = Path(out_dir)
    out_path_dir.mkdir(parents=True, exist_ok=True)
    root = Path(transcripts_root)

    print(f"Processing {len(rows)} witnesses with {max_workers} workers ...")
    print(f"Tests: {[t[0] for t in TESTS_CONFIG]}  archetypes: {[t[3] for t in TESTS_CONFIG]}")

    done = 0
    with ThreadPoolExecutor(max_workers=max_workers) as ex:
        futures = {ex.submit(process_witness, row, root, out_path_dir): row for row in rows}
        for fut in as_completed(futures):
            row = futures[fut]
            done += 1
            try:
                result = fut.result()
            except Exception as e:
                result = {"id": row["ID"], "status": "error", "error": str(e)}
            print(f"[{done}/{len(rows)}] {row['ID']} ({row['Title'][:50]!r}): {result['status']}"
                  + (f" ({result.get('test_errors')} test errors)" if result.get("test_errors") else "")
                  + (f" [{result.get('n_supp_docs')} supp docs]" if result.get("n_supp_docs") is not None else "")
                  + (" [WITNESS NAME UNCERTAIN]" if result.get("witness_name_uncertain") else "")
                  + (f" — {result.get('error')}" if result.get("error") else ""))

    print("\nDone.")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("csv_path")
    parser.add_argument("--transcripts-root", default=str(Path(__file__).resolve().parent.parent / "sample_300" / "transcripts"))
    parser.add_argument("--out", default=str(Path(__file__).resolve().parent.parent / "sample_300" / "batch_results"))
    parser.add_argument("--workers", type=int, default=6)
    args = parser.parse_args()
    main(args.csv_path, args.transcripts_root, args.out, args.workers)
