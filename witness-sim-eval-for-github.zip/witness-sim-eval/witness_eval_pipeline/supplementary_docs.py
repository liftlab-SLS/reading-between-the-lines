"""
Fetch real supplementary case documents for a witness from the UCSF
Industry Documents Library's public Solr index, to populate the
`doc_context` parameter that batch_sim.py's persona builder already
supports (`--docs` CLI flag / `build_persona_from_questions`'s doc_context
param) but which this pipeline has never actually populated with anything.

Full-text search (not just title/author fields) across the SAME
collection/case the witness's deposition came from surfaces genuinely
relevant material — emails to/from them, memos, exhibits — not just
documents whose metadata happens to name them.
"""

import json
import re
import urllib.parse
import urllib.request

SOLR_BASE = "https://solr.idl.ucsf.edu/solr/ltdl3/select"
DOWNLOAD_BASE = "https://download.industrydocuments.ucsf.edu"

_STOPWORDS = {
    "the", "and", "for", "with", "that", "this", "from", "were", "was", "are", "is",
    "team's", "team", "data", "about", "into", "their", "these", "those", "during",
    "which", "when", "while", "over", "under", "regarding", "related", "process",
}
_PROPER_NOUN_RUN = re.compile(r"\b(?:[A-Z][a-zA-Z0-9'.]*\s*){2,}")


def extract_search_terms(phrase: str, max_terms: int = 4) -> list[str]:
    """
    case_prep's topic/fact phrases are LLM-written summaries ("the risk
    management team's discussions of abuse and diversion data for Opana
    ER"), not verbatim corpus text — quoting the whole sentence as an exact
    phrase for a Solr search will essentially never match anything real.
    Extract what's actually likely to appear verbatim instead: proper-noun
    runs (product names, places — "Opana ER", "Hawkins County") first,
    then individual significant words as a fallback.
    """
    if not phrase:
        return []
    proper_nouns = [m.group().strip() for m in _PROPER_NOUN_RUN.finditer(phrase)]
    proper_nouns = [p for p in proper_nouns if len(p) > 3]

    words = [w.strip(".,;:'\"") for w in phrase.split()]
    significant_words = [
        w for w in words
        if len(w) >= 5 and w.lower() not in _STOPWORDS and not w[0].isupper()
    ]

    terms = list(dict.fromkeys(proper_nouns + significant_words))  # dedupe, preserve order
    return terms[:max_terms]


def _solr_query(params: dict) -> dict:
    url = SOLR_BASE + "?" + urllib.parse.urlencode(params)
    req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0 research-download"})
    with urllib.request.urlopen(req, timeout=30) as resp:
        return json.load(resp)


def get_doc_metadata(doc_id: str) -> dict:
    """Look up a document's own collectioncode/case/bates-number by ID."""
    data = _solr_query({"q": f"id:{doc_id}", "wt": "json", "fl": "id,collectioncode,case,bn"})
    docs = data["response"]["docs"]
    if not docs:
        return {}
    d = docs[0]
    return {
        "collectioncode": (d.get("collectioncode") or [None])[0],
        "case": (d.get("case") or [None])[0],
        "bn": d.get("bn"),
    }


_ADMIN_TITLE_KEYWORDS = [
    "payroll", "requisition", "purchase approval", "expense report",
    "time sheet", "direct deposit", "benefits enrollment", "invoice",
]


def _is_admin_title(title: str) -> bool:
    t = title.lower()
    return any(kw in t for kw in _ADMIN_TITLE_KEYWORDS)


def _valid_hits(docs: list[dict], exclude_admin_titles: bool = True) -> list[dict]:
    """
    Filter Solr hits down to ones with an actual downloadable .ocr
    artifact. HR/administrative paperwork (payroll summaries, purchase
    requisitions) can't be excluded via a Solr `ti:` field query — the
    title/filename isn't tokenized the way the general full-text body is
    (confirmed: `ti:payroll` and even a bare `q="payroll"` both return
    zero matches for a document literally titled
    "Payroll_Summary_(2019.05.24).pdf" — it was actually surfaced via her
    name appearing in the document's OCR body, e.g. a payroll table row,
    not its filename). Filtering the returned `ti` string client-side
    works fine since Solr still returns it correctly as stored data.
    """
    out = []
    for d in docs:
        artifact_raw = d.get("artifact") or ["[]"]
        try:
            arts = json.loads(artifact_raw[0])
        except (json.JSONDecodeError, IndexError):
            continue
        ocr = next((a for a in arts if a["name"].endswith(".ocr")), None)
        if not ocr:
            continue
        title = d.get("ti", "")
        if exclude_admin_titles and _is_admin_title(title):
            continue
        out.append({
            "id": d["id"], "title": title, "dt": d.get("dt", []), "ocr_size": ocr["size"],
            "case": (d.get("case") or [None])[0],
        })
    return out


_STATEMENT_KEYWORDS = ["declaration", "affidavit", "statement", "certification", "fact sheet", "summary"]


def extract_surname(witness_name: str) -> str:
    """
    Legal documents overwhelmingly refer to people by surname (or courtesy
    title + surname), not full "First Last" name — requiring the full name
    is needlessly restrictive. Empirically: within one real case, the full
    hyphenated name "Kristin Vitanza-Squires" matched only 3 documents,
    while the surname alone matched 138,331 — and the TOP-ranked hits for
    the bare surname were all genuinely, specifically about her ("Kristin
    Vitanza" personnel record, "Purchase Approval Request for Kristin
    Vitanza", a meeting invite naming her). The large raw count reflects a
    2.6-million-document case, not noise — Solr's relevance ranking (and
    this module's own tiering) already handles specificity.
    """
    parts = witness_name.strip().split()
    return parts[-1] if parts else witness_name


def find_supplementary_docs(witness_name: str, doc_id: str, collectioncode: str | None,
                             case_name: str | None = None, topic_terms: list[str] | None = None,
                             max_docs: int = 5, random_seed: int = 1) -> list[dict]:
    """
    Full-text search scoped to the witness's own SPECIFIC case, not just
    their broader collection — a collection like "Teva and Allergan
    Documents" or "Mallinckrodt Litigation Documents" can span more than
    one distinct lawsuit (MDL, state AG actions, bankruptcy, private
    suits), so collectioncode alone risks pulling in documents from an
    unrelated case that just happens to share a common witness surname.
    Falls back to collectioncode-only if this document has no `case`
    value (rare, but happens).

    Every tier tries the FULL NAME first, falling back to SURNAME ALONE
    only if the full name yields nothing for that tier. Surname-only
    search is necessary for rare/hyphenated names (legal documents refer
    to people by surname, not "First Last" — full-name-only search found
    just 3 documents total for "Kristin Vitanza-Squires" across an entire
    case), but for a common surname it's a real liability: for "Adams",
    surname-only search combined with declaration/affidavit keywords
    pulled in a "Declaration of Thomas Adams" and a "Mark Adams" affidavit
    — different people, confirmed by reading the actual OCR text ("the
    supporting Declaration of Thomas Adams" — a Purdue Pharma filing
    unrelated to this witness). Trying the full name first avoids this for
    common surnames while still getting the surname's reach for rare ones.
    Hits found only via the surname fallback are tagged with a
    "(surname-only)" suffix on match_tier so this is auditable.

    Five tiers in priority order — each tier only runs if the previous one
    didn't fill max_docs. Tiers 1-4 actively exclude routine correspondence
    (dt:email, dt:calendar) — an out-of-office notice or a "To: X"
    one-liner technically mentions the witness but carries essentially no
    substantive content. Only the final fallback tier allows it back in,
    and only if nothing more substantive exists at all:
      1. "statement_or_summary" — name AND a declaration/affidavit/
         statement/certification/fact-sheet/summary keyword: their own
         formal statements or case-team-prepared summaries about them,
         the most specifically-about-them material available.
      2. "name+topic" — name AND keywords extracted from case_prep's
         sensitive_topic/aggravating_fact: documents tied to the SPECIFIC
         subject matter they testified about, not just any mention of them.
      3. "name_relevance" — name alone (title matches boosted), Solr's
         default relevance ranking, non-routine document types only.
      4. "random_sample" — name alone, server-side random-sorted, still
         non-routine only, to fill remaining slots with variety rather
         than always the same handful of top-relevance hits.
      5. "routine_fallback" — name alone, ANY document type including
         email/calendar — only reached if tiers 1-4 combined still didn't
         reach max_docs.
    Excludes the transcript document itself and any video companion
    record. Returns only hits with an actual downloadable .ocr artifact.
    """
    if not collectioncode and not case_name:
        return []

    surname = extract_surname(witness_name)
    has_distinct_surname = surname != witness_name
    scope_fq = f'case:"{case_name}"' if case_name else f"collectioncode:{collectioncode}"
    base_fq = f"{scope_fq} AND -id:{doc_id} AND -dt:video"
    # dt:email/dt:calendar reliably catches routine correspondence (dt is a
    # proper structured field). HR/administrative paperwork (payroll,
    # requisitions) can't be excluded this way — see _valid_hits, which
    # filters those out client-side on the returned title string instead.
    non_routine_fq = f"{base_fq} AND -dt:email AND -dt:calendar"

    results: list[dict] = []
    seen_ids: set[str] = set()

    def _search(q: str, tier: str, rows: int, fq_base: str, sort: str | None = None) -> int:
        exclude_fq = fq_base + "".join(f" AND -id:{i}" for i in seen_ids)
        params = {"q": q, "fq": exclude_fq, "rows": str(rows), "wt": "json", "fl": "id,ti,dt,pg,artifact,case"}
        if sort:
            params["sort"] = sort
        data = _solr_query(params)
        added = 0
        for hit in _valid_hits(data["response"]["docs"]):
            if hit["id"] in seen_ids:
                continue
            hit["match_tier"] = tier
            results.append(hit)
            seen_ids.add(hit["id"])
            added += 1
            if len(results) >= max_docs:
                return added
        return added

    def _run(build_q, tier: str, rows: int, fq_base: str, sort: str | None = None) -> None:
        """build_q(name) -> query string. Tries witness_name first, surname only as fallback."""
        _search(build_q(witness_name), tier, rows, fq_base, sort)
        if len(results) >= max_docs:
            return
        if has_distinct_surname:
            _search(build_q(surname), f"{tier} (surname-only)", rows, fq_base, sort)

    statement_clause = " OR ".join(f'"{k}"' for k in _STATEMENT_KEYWORDS)
    _run(lambda n: f'"{n}" AND ({statement_clause})', "statement_or_summary", max_docs * 4, non_routine_fq)
    if len(results) >= max_docs:
        return results

    if topic_terms:
        keywords: list[str] = []
        for phrase in topic_terms:
            keywords.extend(extract_search_terms(phrase))
        keywords = list(dict.fromkeys(keywords))
        if keywords:
            topic_clause = " OR ".join(f'"{k}"' for k in keywords)
            _run(lambda n: f'"{n}" AND ({topic_clause})', "name+topic", max_docs * 4, non_routine_fq)
            if len(results) >= max_docs:
                return results

    _run(lambda n: f'ti:"{n}"^5 OR "{n}"', "name_relevance", (max_docs - len(results)) * 4, non_routine_fq)
    if len(results) >= max_docs:
        return results

    _run(lambda n: f'"{n}"', "random_sample", (max_docs - len(results)) * 6, non_routine_fq,
         sort=f"random_{random_seed} asc")
    if len(results) >= max_docs:
        return results

    _run(lambda n: f'"{n}"', "routine_fallback", (max_docs - len(results)) * 4, base_fq)

    return results


_CASE_BACKGROUND_KEYWORDS = [
    "complaint", "case summary", "statement of facts", "fact sheet",
    "background", "overview", "case management order", "master settlement agreement",
]


def find_case_background_docs(doc_id: str, collectioncode: str | None,
                               case_name: str | None = None, max_docs: int = 5) -> list[dict]:
    """
    When a witness's own name can't be confidently extracted (e.g. a
    multi-day trial-transcript continuation fragment where the witness was
    only named on an earlier day's file — see transcript_ingest.py), we
    can't search BY them. But we still know their case, so we can still
    ground the persona in general case-level material — the complaint,
    a case summary/fact sheet, settlement background — rather than
    leaving doc_context empty. Title-focused search, since foundational
    case documents are reliably named as such ("Consolidated Amended
    Complaint", "Master Settlement Agreement"). Same non-routine
    filtering as find_supplementary_docs.
    """
    if not collectioncode and not case_name:
        return []

    scope_fq = f'case:"{case_name}"' if case_name else f"collectioncode:{collectioncode}"
    base_fq = f"{scope_fq} AND -id:{doc_id} AND -dt:video AND -dt:email AND -dt:calendar"

    keyword_clause = " OR ".join(f'ti:"{k}"' for k in _CASE_BACKGROUND_KEYWORDS)
    data = _solr_query({
        "q": keyword_clause, "fq": base_fq, "rows": str(max_docs * 4),
        "wt": "json", "fl": "id,ti,dt,pg,artifact,case",
    })
    hits = _valid_hits(data["response"]["docs"])[:max_docs]
    for h in hits:
        h["match_tier"] = "case_background"
    return hits


def download_ocr_text(doc_id: str, max_chars: int = 1200) -> str:
    a, b, c, e = doc_id[0], doc_id[1], doc_id[2], doc_id[3]
    url = f"{DOWNLOAD_BASE}/{a}/{b}/{c}/{e}/{doc_id}/{doc_id}.ocr"
    req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0 research-download"})
    with urllib.request.urlopen(req, timeout=30) as resp:
        data = resp.read()
    return data.decode("utf-8", errors="replace")[:max_chars]


def _assemble_context(hits: list[dict], max_chars_per_doc: int) -> tuple[str, list[dict]]:
    parts = []
    fetched = []
    for d in hits:
        try:
            text = download_ocr_text(d["id"], max_chars=max_chars_per_doc)
        except Exception:
            continue
        parts.append(f"--- {d['title']} (doc {d['id']}) ---\n{text}")
        fetched.append(d)
    return "\n\n".join(parts), fetched


def build_doc_context(witness_name: str, doc_id: str, collectioncode: str | None,
                       case_name: str | None = None, topic_terms: list[str] | None = None,
                       max_docs: int = 5, max_chars_per_doc: int = 1000) -> tuple[str, list[dict]]:
    """
    Returns (doc_context_text, supp_docs_metadata) — the concatenated
    excerpts ready to pass as persona.build_persona(doc_context=...), plus
    the list of what was actually fetched (for logging/auditing which real
    documents ended up shaping a given persona).
    """
    supp_docs = find_supplementary_docs(
        witness_name, doc_id, collectioncode, case_name=case_name, topic_terms=topic_terms, max_docs=max_docs,
    )
    return _assemble_context(supp_docs, max_chars_per_doc)


def build_case_background_context(doc_id: str, collectioncode: str | None, case_name: str | None = None,
                                    max_docs: int = 5, max_chars_per_doc: int = 1000) -> tuple[str, list[dict]]:
    """
    Same output shape as build_doc_context, but for witnesses whose own
    name couldn't be confidently extracted — falls back to general
    case-level background material (see find_case_background_docs)
    instead of skipping supplementary enrichment entirely.
    """
    hits = find_case_background_docs(doc_id, collectioncode, case_name=case_name, max_docs=max_docs)
    return _assemble_context(hits, max_chars_per_doc)
