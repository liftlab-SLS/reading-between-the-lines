"""
Extract the fact-slots every test template needs (entity name, a sensitive
topic + a structurally-matched neutral control topic, an aggravating fact,
a real exhibit + what it reveals, and a yes/no-answerable "position" probe)
from ONE witness's OWN real transcript — never from a shared/generic bank.

This is what makes the test battery generic across defendants: swap the
witness, get a new fact set, same test code. It's also what makes T4/U4
possible at all — an exhibit and a contradiction can't be invented
generically, they have to come from the actual record.

Each extracted fact also carries the transcript turn index it first became
relevant at, so callers know how many real turns they can safely warm up
with before that fact/topic/exhibit stops being "fresh" (untouched, so its
memory `rho` in WitnessSim hasn't already decayed before a test injects it).
"""

import json
import re
from pathlib import Path

from dotenv import load_dotenv

load_dotenv(Path(__file__).resolve().parent.parent / ".env")

import anthropic

from llm_utils import response_text

EXTRACTOR_MODEL = "claude-sonnet-5"

_EXHIBIT_PATTERN = re.compile(r"(?:Trial\s+|Deposition\s+)?Exhibit\s*(?:No\.?\s*)?(\d+)", re.IGNORECASE)


def find_exhibit_mentions(turns: list[dict], context_window: int = 1) -> list[dict]:
    """
    Regex scan for real exhibit references (e.g. "Exhibit 14") in the
    transcript, with surrounding turns for context. Cheap and reliable —
    the LLM step only has to pick and characterize one, not invent a
    number that doesn't exist in the record.
    """
    hits = []
    seen_labels = set()
    for i, t in enumerate(turns):
        for m in _EXHIBIT_PATTERN.finditer(t["text"]):
            label = f"Exhibit {m.group(1)}"
            if label in seen_labels:
                continue
            seen_labels.add(label)
            lo, hi = max(0, i - context_window), min(len(turns), i + context_window + 1)
            context = " / ".join(f"[{turns[j]['role']}] {turns[j]['text']}" for j in range(lo, hi))
            hits.append({"turn_index": i, "label": label, "context": context})
    return hits


SYSTEM_PROMPT = """You are preparing case-specific test materials for an evaluation of a \
deposition simulator, by extracting real facts from ONE witness's actual real deposition \
transcript. Every fact you return must be grounded in the transcript excerpts given to you — \
never invent facts, names, dates, or documents that don't appear in the material.

You must return a single JSON object (no markdown fences, no commentary) with exactly these \
fields:

{
  "entity_name": string,               // the defendant/company/organization the witness worked for or is being examined about
  "sensitive_topic": {
    "phrase": string,                  // a short, legally sensitive topic this witness was actually examined about
                                        // (e.g. "the process for identifying and reporting suspicious opioid orders")
    "first_turn_index": integer        // the turn index where this topic is FIRST raised in the transcript
  },
  "neutral_control_topic": {
    "phrase": string                   // a topic that is STRUCTURALLY IDENTICAL in phrasing/scope to sensitive_topic,
                                        // but factually neutral/mundane (e.g. if sensitive_topic is "the process for
                                        // identifying suspicious orders", this should be something like "the process
                                        // for onboarding new employees") — same sentence shape, unrelated substance
  },
  "aggravating_fact": {
    "phrase": string,                  // a specific, damaging allegation or fact relevant to this witness, suitable
                                        // for a high-pressure "isn't it true you knew..." style question
    "first_turn_index": integer
  },
  "exhibit": {
    "label": string,                   // MUST be one of the candidate exhibit labels given to you below — do not invent one
    "description": string,             // a short description of what the document is (e.g. "a March 2011 email
                                        // from the DEA's Diversion Division")
    "reveal_fact": string,             // the specific fact this document appears to establish about the witness
                                        // or their knowledge, based on the surrounding transcript context
    "first_turn_index": integer
  },
  "prior_position_probe": {
    "question": string,                // a single yes/no-answerable question this witness could take a clear,
                                        // testable position on early in a deposition (e.g. "did you ever personally
                                        // flag or report a concern about X to your compliance team or to the DEA?")
                                        // grounded in this witness's actual role/case content — you do not need to
                                        // know or predict their real answer, just produce a well-formed probe
    "first_turn_index": integer
  }
}

If the transcript excerpts genuinely don't support one of these fields (e.g. no exhibit was \
ever discussed), set that field to null rather than fabricating one.
"""


def _build_user_message(witness_name: str, entity_hint: str | None,
                         attorney_turns: list[dict], exhibit_candidates: list[dict]) -> str:
    q_lines = "\n".join(f"[{t['turn_index']}] {t['text']}" for t in attorney_turns)
    exhibit_lines = "\n".join(
        f"- {h['label']} (first appears at turn {h['turn_index']}): {h['context'][:300]}"
        for h in exhibit_candidates
    ) or "(none found)"

    entity_line = f"Likely entity/employer: {entity_hint}\n" if entity_hint else ""

    return (
        f"Witness: {witness_name}\n"
        f"{entity_line}"
        f"\nAttorney's examination questions (turn index in brackets):\n{q_lines}\n"
        f"\nCandidate real exhibits mentioned in this transcript:\n{exhibit_lines}\n"
    )


def extract_case_prep(witness_name: str, turns: list[dict], attorney_name: str | None = None,
                       entity_hint: str | None = None,
                       client: anthropic.Anthropic | None = None,
                       model: str = EXTRACTOR_MODEL,
                       max_questions: int = 500) -> dict:
    """
    One Claude call per witness. Returns the case-prep dict described in
    SYSTEM_PROMPT's schema, plus the raw exhibit candidates for auditing.
    """
    client = client or anthropic.Anthropic()

    attorney_turns = [
        t for t in turns
        if t["role"] == "attorney" and (attorney_name is None or t["attorney"] == attorney_name)
    ][:max_questions]

    exhibit_candidates = find_exhibit_mentions(turns)

    user_message = _build_user_message(witness_name, entity_hint, attorney_turns, exhibit_candidates)

    response = client.messages.create(
        model=model,
        max_tokens=1536,
        system=SYSTEM_PROMPT,
        thinking={"type": "disabled"},
        messages=[{"role": "user", "content": user_message}],
    )
    raw = response_text(response).strip()
    match = re.search(r"\{.*\}", raw, re.DOTALL)
    if not match:
        raise ValueError(f"case_prep_extractor: no JSON found in response for {witness_name}: {raw[:500]}")

    case_prep = json.loads(match.group())
    case_prep["_exhibit_candidates"] = exhibit_candidates
    case_prep["_witness_name"] = witness_name
    return case_prep


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("transcript_path")
    args = parser.parse_args()

    from transcript_ingest import ingest_transcript

    result = ingest_transcript(args.transcript_path)
    case_prep = extract_case_prep(
        result["witness_name"] or "Unknown Witness",
        result["turns"],
        attorney_name=result["attorney_name"],
    )
    print(json.dumps({k: v for k, v in case_prep.items() if k != "_exhibit_candidates"}, indent=2))
