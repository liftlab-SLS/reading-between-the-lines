#!/usr/bin/env python3
"""
Full smoke test for all 10 tests (U1-U4, T1-T6): reuses a single ingestion/
case-prep/persona pass, then runs each test against ITS OWN primary+control
archetype pair from the doc (not the full 11-archetype set — that's the
larger run this step is deliberately deferring). Warm-up sessions are
cached per archetype so archetypes reused across multiple tests aren't
re-warmed.
"""

import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

import anthropic

from case_prep_extractor import extract_case_prep
from persona import build_persona
from session_runner import ARCHETYPES, warm_up
from transcript_ingest import ingest_transcript

from tests import (
    u1_question_form, u2_sensitive_topic, u3_pressure_recovery, u4_contradiction,
    t1_evasive_pindown, t2_runaway_witness, t3_hostile_control,
    t4_fragile_memory, t5_rigidity_offramp, t6_overprepared_fatigue,
)

# (test module, kind, [archetype_names to run]) — one primary + one control
# per test, per the doc's own primary/control tables.
PLAN = [
    ("U1", u1_question_form, "warm", ["Cooperative", "Combative"]),
    ("U2", u2_sensitive_topic, "cold", ["Cooperative", "Combative"]),
    ("U3", u3_pressure_recovery, "warm", ["Cooperative", "Combative"]),
    ("U4", u4_contradiction, "warm", ["Cooperative", "Combative"]),
    ("T1", t1_evasive_pindown, "warm", ["Evasive", "Cooperative"]),
    ("T2", t2_runaway_witness, "warm", ["Loquacious", "Neutral"]),
    ("T3", t3_hostile_control, "warm", ["Combative", "Cooperative"]),
    ("T4", t4_fragile_memory, "warm", ["Nervous", "Overprepared"]),
    ("T5", t5_rigidity_offramp, "warm", ["Dogmatic", "Cooperative"]),
    ("T6", t6_overprepared_fatigue, "cold", ["Overprepared", "Neutral"]),
]

WARMUP_N = 10
_FRESHNESS_FIELDS = ["sensitive_topic", "aggravating_fact", "exhibit", "prior_position_probe"]


def select_warmup_questions(turns, case_prep, attorney_name, n=WARMUP_N):
    cutoffs = [
        case_prep[f]["first_turn_index"] for f in _FRESHNESS_FIELDS
        if case_prep.get(f) and case_prep[f].get("first_turn_index") is not None
    ]
    cutoff = min(cutoffs) if cutoffs else len(turns)
    candidates = [
        t for t in turns
        if t["role"] == "attorney" and (attorney_name is None or t["attorney"] == attorney_name)
        and t["turn_index"] < cutoff
    ]
    return [t["text"] for t in candidates[:n]]


def main(transcript_path: str, out_dir: str):
    client = anthropic.Anthropic()

    print(f"Ingesting {transcript_path} ...")
    ingested = ingest_transcript(transcript_path)
    witness_name = ingested["witness_name"] or Path(transcript_path).stem
    print(f"  witness={witness_name!r} attorney={ingested['attorney_name']!r} turns={len(ingested['turns'])}")

    print("Extracting case prep ...")
    case_prep = extract_case_prep(
        witness_name, ingested["turns"], attorney_name=ingested["attorney_name"], client=client,
    )
    print(json.dumps({k: v for k, v in case_prep.items() if not k.startswith("_")}, indent=2))

    warmup_questions = select_warmup_questions(ingested["turns"], case_prep, ingested["attorney_name"])
    print(f"Warm-up: {len(warmup_questions)} real attorney questions")

    attorney_turns_all = [
        t for t in ingested["turns"]
        if t["role"] == "attorney" and t["attorney"] == ingested["attorney_name"]
    ]
    print("Building persona ...")
    persona = build_persona(
        witness_name, [t["text"] for t in attorney_turns_all],
        attorney=ingested["attorney_name"], case_prep=case_prep, client=client,
    )
    print(f"  role={persona['role']!r} org={persona['organization']!r}")

    warmed_cache: dict = {}
    all_results: dict = {}

    for test_name, mod, kind, archetype_names in PLAN:
        print(f"\n=== {test_name} ({kind} start) ===")
        all_results[test_name] = {}
        for archetype_name in archetype_names:
            archetype_state = ARCHETYPES[archetype_name]
            if kind == "warm":
                if archetype_name not in warmed_cache:
                    print(f"  warming up {archetype_name} ...")
                    warmed_cache[archetype_name] = warm_up(persona, archetype_state, warmup_questions, client=client)
                state_arg = warmed_cache[archetype_name]
            else:
                state_arg = archetype_state

            print(f"  running {archetype_name} ...")
            result = mod.run(persona, archetype_name, state_arg, case_prep, client=client)
            all_results[test_name][archetype_name] = result

    out_path_dir = Path(out_dir)
    out_path_dir.mkdir(parents=True, exist_ok=True)
    out_path = out_path_dir / f"{witness_name.replace(' ', '_')}_all_tests_results.json"
    out_path.write_text(json.dumps(all_results, indent=2, default=str))
    print(f"\nWrote results to {out_path}")
    return all_results


if __name__ == "__main__":
    transcript = sys.argv[1] if len(sys.argv) > 1 else (
        "/Users/divya/emotion-analysis/opioid_deposition_transcripts/transcripts/"
        "Mallinckrodt Litigation Documents/xknv0249_Adams Depo Packet.pdf.txt"
    )
    out = sys.argv[2] if len(sys.argv) > 2 else str(Path(__file__).resolve().parent / "fixtures")
    main(transcript, out)
