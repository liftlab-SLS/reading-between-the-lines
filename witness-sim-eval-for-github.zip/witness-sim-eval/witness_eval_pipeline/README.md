# WitnessSim Evaluation Pipeline

Automates the human-annotation protocol in `Eval Plan (2).pdf` (10 tests:
U1-U4 "Universal Perturbation Tests," T1-T6 "Targeted Skill-Archetype
Stress Tests") against the real [WitnessSim simulator](../witness-sim-ai4law).

The doc's "AUTOMATED" fields (word count, ODE state values) were already
mechanical — this pipeline reads them straight from `state_engine.py`. The
doc's "ANNOTATE" fields (direct answer score, hedge count, response
category, tone, etc.) were designed for a human reading transcripts with a
pen; here an LLM judge scores them instead, using the same rubric
definitions — but with the doc's example hedge/formulaic phrase lists
treated as illustrations of a *functional category*, not a literal string
match. (Confirmed working: the judge correctly flags hedges like "I
couldn't tell you for certain" and "that's not something I'd want to swear
to," neither of which appears in the doc's own example list.)

## What's generic vs. what's a worked example

Every test is parameterized by `case_prep_extractor.py`'s output
(entity name, sensitive topic + matched neutral control, an aggravating
fact, a *real* exhibit pulled from the actual transcript, a yes/no
position probe) — extracted fresh from whichever witness's transcript you
point it at, not hardcoded to Mallinckrodt. The doc's own question wording
is Mallinckrodt-specific; this pipeline generalizes the *pattern* (open /
closed / leading / high-pressure framing, exact classifier-matching
prefixes/suffixes) while filling in whatever facts that witness's own
record actually supports.

Per your scope call, this builds and proves the pipeline — it does not
implement the actual large-scale witness-sampling procedure across the
~500 real transcripts in `opioid_deposition_transcripts/`. Every smoke test
so far uses one worked example (John Adams, Mallinckrodt Litigation
Documents) against 1-2 archetypes per test, not the full witness/archetype
grid.

## Two known deviations from the doc, both deliberate

1. **Archetypes: 11, not 10.** The doc's U-test header says "all 10
   archetypes" (echoing the paper's 10, which excludes Evasive), but T1,
   T2, and T4 all list Evasive as a *primary* archetype in their own
   tables — so the doc's own content requires 11, not 10. Using the union
   of every archetype named anywhere in the doc (`rubrics.ARCHETYPES_IN_SCOPE`):
   Combative, Cooperative, Defensive, Dogmatic, Evasive, Inventive,
   Loquacious, Neutral, Nervous, Overconfident, Overprepared.

2. **Cold start (turn 1, archetype attractor) vs. warm start (mid-deposition
   state via a real-transcript warm-up):**
   - **Warm** (the default, `session_runner.warm_up` + `fork_for_test`):
     U1, U3, U4, T1-T5. Replays the witness's own real early attorney
     questions once, producing a genuinely case-grounded state — then
     forks state/memory/persona forward but **drops the literal
     conversation history** (fresh `messages: []`). This isolates whether
     the ODE state alone reproduces a test's predicted behavior, rather
     than conflating it with the model's tendency to stay consistent with
     specific prior wording, and sidesteps any "does the injected question
     read naturally after the warm-up" problem — there's no prior
     utterance to be inconsistent with.
   - **Cold** (`new_session`, no warm-up): U2 and T6 only.
     - U2 explicitly requires it ("run each condition as a completely
       separate fresh deposition... you need identical s0 starting state
       for both") — the whole point is testing the sensitivity-encoding
       mechanism in isolation.
     - T6 requires it mechanically: its fatigue term
       `phi_t = min(1, t/20)` is turn-indexed, and forking from an
       already-nonzero turn counter would shift its scored turns (5/15/25)
       to a different point on the fatigue curve than the doc intends.

## A real bug this pipeline caught (not a pipeline bug — a WitnessSim behavior)

`state_engine.encode_question`'s topic "sensitivity" is computed via
Jaccard token overlap between the question text and
`persona["sensitive_topics"]` entries. `build_persona` (an LLM call) and
`case_prep_extractor` (a separate LLM call) generate their own topic
wording independently — with no shared vocabulary enforced, they almost
never overlap enough to clear the 0.15 similarity threshold, silently
zeroing out sensitivity (and therefore `K` decay, memory `rho` tracking)
for every test that injects a case-prep-derived question. This is exactly
the failure mode U2's own "Step 2 — verify s_t scores before annotation"
warns about. Fixed in `persona.seed_case_prep_topics`: after building a
persona, case_prep's `sensitive_topic` and `aggravating_fact` phrases are
appended verbatim as memory keys (unless something persona already
generated is already a close match). Confirmed fixed: sensitivity now
reads ~0.58 on the sensitive condition and 0.0 on the matched neutral
control, for both archetypes tested.

## Files

| File | Purpose |
|---|---|
| `transcript_ingest.py` | UCSF OCR text -> clean attorney/witness turns (ported/extended from `analyze_depositions.ipynb::parse_transcript`) |
| `case_prep_extractor.py` | Per-witness fact extraction from their own real transcript |
| `persona.py` | Persona builder (ported from `batch_sim.py`, current model ID) + the sensitivity-seeding fix |
| `session_runner.py` | `state_engine`/`prompt_builder` wrapper: `run_turn`, `warm_up`, `fork_for_test`, parallel-injection cloning |
| `rubrics.py` | Every test's ANNOTATE schema, transcribed from the doc as data |
| `judge_prompts.py` | Generic LLM-judge engine (funnel-classifier pattern: rubric + strict JSON contract) |
| `tests/*.py` | One module per test (U1-U4, T1-T6) |
| `run_eval.py` | CLI: one witness transcript -> N archetypes -> M tests -> JSON |
| `smoke_test_all.py` | The actual smoke-test driver used so far — runs all 10 tests, each against its own primary+control archetype pair |
| `fixtures/` | Smoke-test output (John Adams, Mallinckrodt) |

## Running it

```bash
# One witness, a couple archetypes, a couple tests:
python run_eval.py <transcript.txt> --archetypes Cooperative Combative --tests U1 U4

# All 10 tests against their doc-specified primary/control pairs:
python smoke_test_all.py <transcript.txt>
```

Needs `ANTHROPIC_API_KEY` in `.env` (project root). Uses `claude-sonnet-5`
throughout (`batch_sim.py`'s hardcoded `claude-sonnet-4-20250514` and the
funnel-classifier's `claude-haiku-4-5` are both retired/unverified against
the current API — this pipeline's own code uses current model IDs, ported
rather than editing the vendored repo).

## What's not done yet

- Only smoke-tested on one witness (John Adams) with 1-2 archetypes per
  test — not the full 11-archetype x 43(+)-witness grid the doc's own
  pass criteria are actually stated against (e.g. "across at least 30 of
  43 witnesses").
- `evaluate.py` (aggregating raw judged results into the doc's exact
  Y/N pass-criteria tables) is not yet built — right now you'd read
  `fixtures/*.json` by hand, as done for this smoke test.
- The witness-sampling procedure across `opioid_deposition_transcripts/`'s
  ~500 real transcripts (deciding which witnesses/defendants to actually
  run at scale) is explicitly out of scope for this pass.
