"""
Turn a real UCSF OCR deposition transcript (.txt, straight from the
industrydocuments.ucsf.edu .ocr artifact) into clean attorney/witness turns.

Two layers:
  1. `clean_ocr_noise()` — strips Golkow/Bates/confidentiality-banner OCR
     noise (same noise `parse_witness_sim_pdfs.py` strips from its own
     pdfplumber-extracted text; here it's applied directly to UCSF's OCR
     text instead, since we never go through a PDF step).
  2. `parse_transcript()` — ported verbatim from
     emotion-analysis/analyze_depositions.ipynb (cell 7). Handles three
     line-numbering formats and splits into attorney/witness turns.

Not specific to any one defendant/collection — works on any deposition
that follows standard court-reporter formatting (line numbers, Q./A.
markers, "BY MR./MS. X:" examination headers).
"""

import re
from pathlib import Path

# ── Layer 1: OCR noise stripping ─────────────────────────────────────────────

# Lines to drop outright: Golkow footer, confidentiality banner, UCSF source
# stamp. (Same noise class as parse_witness_sim_pdfs.py's _STRIP, applied to
# raw OCR text instead of pdfplumber output.)
_STRIP_LINE = re.compile(
    r"^(?:"
    r"Highly Confidential"
    r"|HIGHLY CONFIDENTIAL"
    r"|Golkow Litigation Services"
    r"|Source:\s*https?://"
    r")",
    re.IGNORECASE,
)

# Bates stamps, standalone on their own line, tolerant of OCR-mangled
# spacing (e.g. "MNKOI 0004556743" or "M N KOI 0004556744" — both seen in
# the same real packet). A real Q/A line never looks like this: it's just
# spaced-out capital letters followed by a long digit run and nothing else.
_BATES_LINE = re.compile(r"^[A-Z](?:\s?[A-Z]){1,12}\s+\d{5,}\s*$")

# OCR sometimes drops the period after Q/A ("1 Q text" instead of "1 Q. text").
# Normalize so parse_transcript()'s qa_pattern can detect it.
_QA_NO_PERIOD = re.compile(r"^(\d{1,2}\s+)([QA])(\s+\S)", re.IGNORECASE)


def clean_ocr_noise(raw_text: str) -> str:
    """Strip Golkow/Bates/confidentiality noise from raw UCSF OCR text."""
    cleaned_lines = []
    for line in raw_text.splitlines():
        stripped = line.strip()
        if not stripped:
            cleaned_lines.append(line)
            continue
        if _STRIP_LINE.match(stripped):
            continue
        if _BATES_LINE.match(stripped):
            continue
        line = _QA_NO_PERIOD.sub(lambda m: m.group(1) + m.group(2) + "." + m.group(3), line)
        cleaned_lines.append(line)
    return "\n".join(cleaned_lines)


# ── Layer 2: turn parsing (ported from analyze_depositions.ipynb cell 7) ────

def parse_transcript_text(raw: str) -> list[dict]:
    """
    Parse cleaned transcript text into a list of turns.
    Handles three formats:
      Format A: '13 Q.  text'  (line numbers, period after Q/A)
      Format B: '·9· · · ·Q.· text'  (middle-dot padding)
      Format C: 'Q: text' / 'A: text'  (simple colon, no line numbers)
    Returns list of dicts: {role, attorney, text, turn_index}
    """
    lines = raw.splitlines()

    fmt_ab = sum(1 for l in lines[:60] if re.match(r"^[\s·]*\d+[\s·]*", l))
    fmt_c = sum(1 for l in lines[:60] if re.match(r"^[QA]:\s", l))
    is_simple = fmt_c > fmt_ab

    cleaned = []
    for line in lines:
        if not is_simple:
            line = re.sub(r"^[\s·]*\d+[\s·]*", "", line)
        cleaned.append(line)

    current_attorney = None
    turns = []
    current_role = None
    current_text_lines = []

    by_pattern = re.compile(
        r"BY\s+(MR\.|MS\.|MRS\.|DR\.)\s*([A-Z][A-Z\s\-']+?):\s*$",
        re.IGNORECASE)
    exam_pattern = re.compile(
        r"(?:CROSS|DIRECT|REDIRECT|RECROSS)?[\s\-]*EXAMINATION\s+BY\s+(MR\.|MS\.|MRS\.|DR\.)\s*([A-Z][A-Z\s\-']+?):\s*$",
        re.IGNORECASE)
    qa_pattern = re.compile(r"^[·\s]*(Q|A)[\.·:]\s*(.*)", re.IGNORECASE)
    intro_pattern = re.compile(
        r"my name is ([A-Z][a-z]+(?:[\-\s][A-Z][a-z]+)+)",
        re.IGNORECASE)

    def flush(role, attorney, lines):
        text = " ".join(lines).strip()
        text = re.sub(r"\s+", " ", text)
        if text and len(text) > 5:
            turns.append({"role": role, "attorney": attorney, "text": text})

    first_q_seen = False

    for line in cleaned:
        stripped = line.strip()

        if re.match(r"^\(?\d{3}\)?\d{3}-\d{4}", stripped):
            continue
        if re.match(r"^A\s*&\s*A Reporting", stripped, re.IGNORECASE):
            continue
        if re.match(r"^Page \d+$", stripped, re.IGNORECASE):
            continue
        if re.match(r"^Veritext", stripped, re.IGNORECASE):
            continue

        exam_match = exam_pattern.search(stripped)
        by_match = by_pattern.search(stripped) if not exam_match else None
        header_match = exam_match or by_match
        if header_match:
            if current_role and current_text_lines:
                flush(current_role, current_attorney, current_text_lines)
                current_text_lines = []
                current_role = None
            title = header_match.group(1).strip()
            name = header_match.group(2).strip().title()
            current_attorney = f"{title} {name}"
            continue

        qa_match = qa_pattern.match(line)
        if qa_match:
            if current_role and current_text_lines:
                flush(current_role, current_attorney, current_text_lines)
                current_text_lines = []
            current_role = "attorney" if qa_match.group(1).upper() == "Q" else "witness"
            rest = qa_match.group(2).strip()
            current_text_lines = [rest] if rest else []

            if current_role == "attorney" and not first_q_seen:
                first_q_seen = True
                intro_m = intro_pattern.search(rest)
                if intro_m and not current_attorney:
                    current_attorney = intro_m.group(1).strip().title()
            continue

        if current_role and stripped:
            if current_role == "attorney" and not current_attorney:
                intro_m = intro_pattern.search(stripped)
                if intro_m:
                    current_attorney = intro_m.group(1).strip().title()
            current_text_lines.append(stripped)

    if current_role and current_text_lines:
        flush(current_role, current_attorney, current_text_lines)

    for i, t in enumerate(turns):
        t["turn_index"] = i

    if all(t["attorney"] is None for t in turns if t["role"] == "attorney"):
        for t in turns:
            if t["role"] == "attorney":
                m = intro_pattern.search(t["text"])
                if m:
                    name = m.group(1).strip().title()
                    for tt in turns:
                        if tt["attorney"] is None:
                            tt["attorney"] = name
                    break

    return turns


def get_main_attorney(turns: list[dict]) -> str | None:
    """Return the attorney name with the most Q turns."""
    from collections import Counter
    attorney_counts = Counter(
        t["attorney"] for t in turns
        if t["role"] == "attorney" and t["attorney"]
    )
    if not attorney_counts:
        return None
    return attorney_counts.most_common(1)[0][0]


# ── Witness name extraction (generic — not Mallinckrodt-specific) ───────────

_WITNESS_NAME_PATTERNS = [
    r"[Dd]eposition [Tt]ranscript of ([A-Z][a-z]+(?:[ \-][A-Z][a-z]+)+)",
    r"[Dd]eponent is ([A-Z][a-z]+(?:[ \-][A-Z][a-z]+)+)",
    # "JAMES RAUSCH, having been first duly sworn" / "..taken pursuant to notice"
    r"\n\s*([A-Z]{2,}(?:[ \-][A-Z]{2,})+),\s*\n?\s*(?:having been|taken pursuant|of lawful age)",
]


def extract_witness_name(raw_text: str) -> str | None:
    """Pull the deponent's name from the cover letter or caption, generically."""
    for pat in _WITNESS_NAME_PATTERNS:
        m = re.search(pat, raw_text)
        if m:
            name = m.group(1).strip()
            return name.title() if name.isupper() else name
    return None


# ── Public entry point ───────────────────────────────────────────────────────

def ingest_transcript(path: str | Path) -> dict:
    """
    Read a UCSF OCR .txt file end to end: clean noise, parse turns, extract
    witness/attorney names.
    Returns {witness_name, attorney_name, turns, source_path}.
    """
    path = Path(path)
    raw = path.read_text(encoding="utf-8", errors="replace")
    cleaned = clean_ocr_noise(raw)
    turns = parse_transcript_text(cleaned)
    witness_name = extract_witness_name(raw)
    attorney_name = get_main_attorney(turns)
    return {
        "witness_name": witness_name,
        "attorney_name": attorney_name,
        "turns": turns,
        "source_path": str(path),
    }


if __name__ == "__main__":
    import argparse
    import json

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("transcript_path", help="Path to a UCSF OCR .txt transcript")
    args = parser.parse_args()

    result = ingest_transcript(args.transcript_path)
    atty_turns = [t for t in result["turns"] if t["role"] == "attorney" and t["attorney"] == result["attorney_name"]]
    witn_turns = [t for t in result["turns"] if t["role"] == "witness"]

    print(f"Witness       : {result['witness_name']}")
    print(f"Main attorney : {result['attorney_name']}")
    print(f"Total turns   : {len(result['turns'])}")
    print(f"Attorney turns (main attorney): {len(atty_turns)}")
    print(f"Witness turns : {len(witn_turns)}")
    if atty_turns:
        print(f"Sample Q: {atty_turns[2]['text'][:120]}")
    if witn_turns:
        print(f"Sample A: {witn_turns[2]['text'][:120]}")
