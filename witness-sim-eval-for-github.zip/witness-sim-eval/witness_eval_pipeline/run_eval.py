#!/usr/bin/env python3
"""
CLI driver: real transcript -> case prep -> persona -> per-archetype warm-up
-> run a set of tests -> write JSON results.

    python run_eval.py <transcript.txt> --archetypes Cooperative Combative --tests U1 U4
"""

import argparse
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

import anthropic

from case_prep_extractor import extract_case_prep
from persona import build_persona
from session_runner import ARCHETYPES, warm_up
from transcript_ingest import ingest_transcript

from tests import (
    u1_question_form, u2_sensitive_topic, u3_pressure_recovery, u4_contradiction,
    t1_evasive_pindown, t2_runaway_witness, t3_hostile_control,
    t4_fragile_memory, t5_rigidity_offramp, t6_overprepared_fatigue,
)

# "warm" tests take a mid-deposition warmed+forked session (the general
# pattern); "cold" tests take the raw archetype_state and start fresh —
# U2 because the doc explicitly requires an uncontaminated s0 comparison,
# T6 because its fatigue term (phi_t = min(1, t/20)) is turn-indexed and
# would be thrown off by a nonzero starting turn counter.
TEST_MODULES = {
    "U1": (u1_question_form, "warm"),
    "U2": (u2_sensitive_topic, "cold"),
    "U3": (u3_pressure_recovery, "warm"),
    "U4": (u4_contradiction, "warm"),
    "T1": (t1_evasive_pindown, "warm"),
    "T2": (t2_runaway_witness, "warm"),
    "T3": (t3_hostile_control, "warm"),
    "T4": (t4_fragile_memory, "warm"),
    "T5": (t5_rigidity_offramp, "warm"),
    "T6": (t6_overprepared_fatigue, "cold"),
}

WARMUP_N = 10
_FRESHNESS_FIELDS = ["sensitive_topic", "aggravating_fact", "exhibit", "prior_position_probe"]


def select_warmup_questions(turns: list[dict], case_prep: dict, attorney_name: str | None,
                            n: int = WARMUP_N) -> list[str]:
    """
    Pick the first `n` real attorney questions that occur strictly before
    every case-prep fact's first_turn_index, so none of the facts this
    run's tests depend on have already been touched (and had their memory
    `rho` decayed) by the warm-up.
    """
    cutoffs = [
        case_prep[f]["first_turn_index"] for f in _FRESHNESS_FIELDS
        if case_prep.get(f) and case_prep[f].get("first_turn_index") is not None
    ]
    cutoff = min(cutoffs) if cutoffs else len(turns)
    candidates = [
        t for t in turns
        if t["role"] == "attorney" and (attorney_name is None or t["attorney"] == attorney_name)
        and t["turn_index"] < cutoff
    ]
    return [t["text"] for t in candidates[:n]]


def run_eval(transcript_path: str, archetypes: list[str], test_names: list[str], out_dir: str) -> dict:
    client = anthropic.Anthropic()

    print(f"Ingesting {transcript_path} ...")
    ingested = ingest_transcript(transcript_path)
    witness_name = ingested["witness_name"] or Path(transcript_path).stem
    print(f"  witness={witness_name!r} attorney={ingested['attorney_name']!r} turns={len(ingested['turns'])}")

    print("Extracting case prep ...")
    case_prep = extract_case_prep(
        witness_name, ingested["turns"], attorney_name=ingested["attorney_name"], client=client,
    )
    print(json.dumps({k: v for k, v in case_prep.items() if not k.startswith("_")}, indent=2))

    warmup_questions = select_warmup_questions(ingested["turns"], case_prep, ingested["attorney_name"])
    print(f"Warm-up: {len(warmup_questions)} real attorney questions")
    for q in warmup_questions:
        print("  -", q[:90])

    attorney_turns_all = [
        t for t in ingested["turns"]
        if t["role"] == "attorney" and t["attorney"] == ingested["attorney_name"]
    ]
    print("Building persona ...")
    persona = build_persona(
        witness_name, [t["text"] for t in attorney_turns_all],
        attorney=ingested["attorney_name"], case_prep=case_prep, client=client,
    )
    print(f"  role={persona['role']!r} org={persona['organization']!r} "
          f"sensitive_topics={len(persona['sensitive_topics'])}")

    out_path_dir = Path(out_dir)
    out_path_dir.mkdir(parents=True, exist_ok=True)

    all_results: dict = {}
    for archetype_name in archetypes:
        if archetype_name not in ARCHETYPES:
            raise ValueError(f"Unknown archetype {archetype_name!r}; available: {list(ARCHETYPES)}")
        archetype_state = ARCHETYPES[archetype_name]
        print(f"\n=== Archetype: {archetype_name} ===")

        needs_warm = any(TEST_MODULES[t][1] == "warm" for t in test_names)
        warmed = None
        if needs_warm:
            warmed = warm_up(persona, archetype_state, warmup_questions, client=client)
            print(f"  post-warm-up state: {warmed['state']}")

        for test_name in test_names:
            mod, kind = TEST_MODULES[test_name]
            print(f"  running {test_name} ({kind} start) ...")
            state_arg = warmed if kind == "warm" else archetype_state
            result = mod.run(persona, archetype_name, state_arg, case_prep, client=client)
            all_results.setdefault(test_name, {})[archetype_name] = result

    out_path = out_path_dir / f"{witness_name.replace(' ', '_')}_results.json"
    out_path.write_text(json.dumps(all_results, indent=2, default=str))
    print(f"\nWrote results to {out_path}")
    return all_results


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("transcript_path")
    parser.add_argument("--archetypes", nargs="+", default=["Cooperative", "Combative"])
    parser.add_argument("--tests", nargs="+", default=["U1", "U4"], choices=list(TEST_MODULES))
    parser.add_argument("--out", default=str(Path(__file__).resolve().parent / "fixtures"))
    args = parser.parse_args()
    run_eval(args.transcript_path, args.archetypes, args.tests, args.out)
