"""
Ported from witness-sim-ai4law/batch_sim.py::build_persona_from_questions —
identical prompt/parsing logic, but with a current model ID. batch_sim.py
hardcodes the now-retired "claude-sonnet-4-20250514" inline (not a
parameter), so it can't be reused as-is without editing the vendored repo;
porting is the same approach transcript_ingest.py already takes for
parse_transcript().

Called directly with an in-memory questions list — never goes through
attorney_questions.zip, since nothing here uses batch_sim.py's CLI/zip
loader (session_runner.py replaces its sequential loop for the same
reason).
"""

import json

import anthropic

from llm_utils import response_text

PERSONA_MODEL = "claude-sonnet-5"


def _jaccard(a: str, b: str) -> float:
    ta, tb = set(a.lower().split()), set(b.lower().split())
    if not ta or not tb:
        return 0.0
    return len(ta & tb) / len(ta | tb)


def seed_case_prep_topics(persona: dict, case_prep: dict) -> dict:
    """
    state_engine.encode_question computes topic "sensitivity" via Jaccard
    token overlap between the QUESTION TEXT and persona["sensitive_topics"]
    keys (session["memory"] is built directly from that list). build_persona
    generates its own topic wording independently of case_prep_extractor, so
    the two essentially never share enough tokens to clear the 0.15
    similarity threshold — which silently zeroes out sensitivity/rho
    tracking for every test that injects a case_prep-derived question,
    exactly the failure mode the Eval Plan doc's own U2 "Step 2 — verify
    s_t scores before annotation" warns about.

    Fix: make sure case_prep's sensitive_topic (and aggravating_fact, since
    U1/U3/T3 inject questions built directly from it too) are present
    verbatim as memory keys, unless something persona already generated is
    already a close match.
    """
    topics = persona.setdefault("sensitive_topics", [])
    existing_phrases = [t.get("topic", "") for t in topics]

    for field, default_sensitivity in (("sensitive_topic", 0.8), ("aggravating_fact", 0.7)):
        entry = case_prep.get(field)
        if not entry or not entry.get("phrase"):
            continue
        phrase = entry["phrase"]
        if any(_jaccard(phrase, existing) > 0.3 for existing in existing_phrases):
            continue
        topics.append({"topic": phrase, "sensitivity": default_sensitivity, "basis": f"case_prep.{field}"})

    return persona


def build_persona(witness_name: str, questions: list[str], attorney: str | None = None,
                   source: str = "", doc_context: str = "", case_prep: dict | None = None,
                   client: anthropic.Anthropic | None = None, model: str = PERSONA_MODEL) -> dict:
    """Use Claude to build a witness persona from real deposition questions."""
    client = client or anthropic.Anthropic()

    q_sample = questions[:80]
    q_text = "\n".join(f"Q. {q}" for q in q_sample)
    attorney = attorney or "unknown attorney"

    # batch_sim.py's original build_persona_from_questions capped this at 3000 chars,
    # sized for a single --docs file. Real supplementary docs fetched from UCSF
    # (supplementary_docs.py, up to 5 docs) run larger than that combined — raised
    # so later docs in the list don't get silently dropped by truncation.
    doc_section = f"\n\nCase document excerpts:\n{doc_context[:6000]}" if doc_context else ""

    prompt = (
        f"You are analyzing a deposition of {witness_name} examined by {attorney} "
        f"(source: {source}).\n\n"
        f"Based on the following attorney questions asked of this witness, "
        f"build a detailed witness persona. Infer their role, organization, "
        f"what they likely know, what they might hide, and what topics are sensitive.\n\n"
        f"Attorney questions (sample):\n{q_text}"
        f"{doc_section}\n\n"
        f"Return a JSON object with fields: name, role, organization, background (string), "
        f"statement (2-3 paragraph narrative), key_points (array of strings), "
        f"known_facts (string), hidden_facts (string), claims (array of "
        f"{{facet, text, confidence 0-1}}), "
        f"sensitive_topics (array of {{topic, sensitivity 0-1, basis}})."
    )

    response = client.messages.create(
        model=model,
        max_tokens=4096,
        system=(
            "Build a realistic legal witness persona from deposition context. "
            "Every claim must be grounded in the questions asked. "
            "Return only valid JSON, no markdown fences."
        ),
        thinking={"type": "disabled"},
        messages=[{"role": "user", "content": prompt}],
    )

    text = response_text(response)
    persona = {}
    try:
        start = text.find("{")
        end = text.rfind("}") + 1
        if start >= 0 and end > start:
            persona = json.loads(text[start:end])
    except (json.JSONDecodeError, ValueError):
        pass

    persona.setdefault("name", witness_name)
    persona.setdefault("role", "Witness")
    persona.setdefault("organization", "Unknown")
    persona.setdefault("background", "")
    persona.setdefault("statement", "")
    persona.setdefault("key_points", [])
    persona.setdefault("known_facts", "")
    persona.setdefault("hidden_facts", "")
    persona.setdefault("claims", [])
    persona.setdefault("sensitive_topics", [])
    persona["name"] = witness_name

    if case_prep is not None:
        persona = seed_case_prep_topics(persona, case_prep)

    return persona
