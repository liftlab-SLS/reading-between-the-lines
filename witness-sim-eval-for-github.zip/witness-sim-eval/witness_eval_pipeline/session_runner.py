"""
Thin engine around the real WitnessSim modules (state_engine, prompt_builder,
batch_sim) that supports the control-flow patterns the Eval Plan doc needs
and batch_sim.py's own fixed sequential loop doesn't:

  - independent single-turn injections from an IDENTICAL starting state
    (U1, U2 — "run each question as a separate injection at the same ODE
    starting state")
  - a real-transcript warm-up whose resulting STATE (not conversation text)
    becomes a test's starting point (see fork_for_test)
  - branching a question's text on a witness's own prior reply (U4)

This never edits the vendored repo — only imports from it. Every state
transition (encode_question / update_state / update_memory / detect_events /
compute_scores) is the actual shipped function, not a reimplementation, so
results can't silently drift from what batch_sim.py itself would produce.
"""

import copy
import os
import sys
from pathlib import Path

REPO_DIR = Path(__file__).resolve().parent.parent / "witness-sim-ai4law"
sys.path.insert(0, str(REPO_DIR))

from dotenv import load_dotenv

load_dotenv(Path(__file__).resolve().parent.parent / ".env")

import anthropic

from state_engine import encode_question, update_state, update_memory, detect_events, compute_scores
from prompt_builder import build_system_prompt, tone_label
from batch_sim import make_session, ARCHETYPES  # noqa: F401 (ARCHETYPES re-exported for convenience)
from llm_utils import response_text

DIALOGUE_MODEL = "claude-sonnet-5"  # batch_sim.py hardcodes the now-retired claude-sonnet-4-20250514;
                                    # this pipeline's own code uses the current equivalent tier instead

_client = None


def get_client() -> anthropic.Anthropic:
    global _client
    if _client is None:
        _client = anthropic.Anthropic()
    return _client


# ── Core turn execution ──────────────────────────────────────────────────────

def new_session(persona: dict, archetype_state: dict) -> dict:
    """Thin wrapper on batch_sim.make_session — no logic duplicated here."""
    return make_session(persona, archetype_state)


def run_turn(session: dict, question_text: str, client: anthropic.Anthropic | None = None,
             model: str = DIALOGUE_MODEL, max_tokens: int = 512) -> dict:
    """
    Execute one encode -> update -> prompt -> call -> record step, mutating
    `session` in place (same contract as batch_sim.run_archetype's per-turn
    body — factored out here so it can be called standalone or in a custom
    sequence instead of only in a fixed full-deposition loop).

    Returns the turn record: {question, reply, state, state_delta, scores,
    encoding, events, tone}.
    """
    client = client or get_client()

    encoding = encode_question(question_text, session)

    prev_state = copy.deepcopy(session["state"])
    new_state = update_state(session["state"], session["state_0"], encoding, session["turn"])
    new_memory = update_memory(session["memory"], encoding["hit_topics"], encoding["pressure"], session["turn"])
    events = detect_events(new_state, prev_state, encoding, question_text)

    system_prompt = build_system_prompt(session, new_state, new_memory, encoding, events)

    history = [{"role": m["role"], "content": m["content"]} for m in session["messages"][-24:]]
    history.append({"role": "user", "content": question_text})

    response = client.messages.create(
        model=model,
        max_tokens=max_tokens,
        system=system_prompt,
        thinking={"type": "disabled"},
        messages=history,
    )
    reply = response_text(response)

    state_delta = {k: round(new_state[k] - prev_state[k], 4) for k in ["C", "K", "A", "V", "R", "P"]}
    scores = compute_scores(new_state)
    tone = tone_label(new_state)

    session["messages"].append({"role": "user", "content": question_text})
    session["messages"].append({
        "role": "assistant", "content": reply,
        "encoding": encoding, "state_delta": state_delta, "scores": scores,
    })
    session["state"] = new_state
    session["memory"] = new_memory
    session["turn"] += 1
    session["trajectory"].append(copy.deepcopy(new_state))
    session["scores_trajectory"].append(scores)

    return {
        "turn": session["turn"],
        "question": question_text,
        "reply": reply,
        "state": copy.deepcopy(new_state),
        "state_delta": state_delta,
        "scores": scores,
        "encoding": encoding,
        "events": events,
        "tone": tone,
    }


# ── Warm-up + state-only handoff to a test ──────────────────────────────────

def warm_up(persona: dict, archetype_state: dict, real_questions: list[str],
            client: anthropic.Anthropic | None = None) -> dict:
    """
    Replay the witness's own real early attorney questions sequentially,
    producing a genuinely case-grounded state/memory. Returns the resulting
    (fully populated, history-included) session — pass this to
    `fork_for_test`, don't hand it to a test directly.
    """
    session = new_session(persona, archetype_state)
    for q in real_questions:
        run_turn(session, q, client=client)
    return session


def fork_for_test(warmed_session: dict) -> dict:
    """
    The state -> test handoff. Deep-copies state/memory/persona/turn
    counter forward from a warmed-up session, but drops the literal
    conversation history (messages reset to []) and restarts the
    trajectory/scores log at this point.

    Rationale: isolates whether the ODE state alone reproduces a test's
    predicted behavior, rather than conflating it with Claude's tendency to
    stay consistent with specific prior wording. Also means there's no
    "does the injected question read naturally after the warm-up" problem —
    there's no prior utterance for it to be inconsistent with. The turn
    counter carries over unchanged because the fatigue term (phi_t =
    min(1, t/20)) is explicitly turn-dependent.
    """
    return {
        "persona": copy.deepcopy(warmed_session["persona"]),
        "mode": warmed_session["mode"],
        "state_0": copy.deepcopy(warmed_session["state_0"]),
        "state": copy.deepcopy(warmed_session["state"]),
        "memory": copy.deepcopy(warmed_session["memory"]),
        "turn": warmed_session["turn"],
        "messages": [],
        "trajectory": [copy.deepcopy(warmed_session["state"])],
        "scores_trajectory": [compute_scores(warmed_session["state"])],
    }


# ── Parallel injection from an identical state (U1 / U2) ────────────────────

def snapshot(session: dict) -> dict:
    """Deep-copy of a session's full mutable state, for later restore()."""
    return copy.deepcopy(session)


def restore(snap: dict) -> dict:
    """Return a fresh, independent session restored from a snapshot."""
    return copy.deepcopy(snap)


def clone_for_parallel_injection(forked_session: dict, n: int) -> list[dict]:
    """
    Return `n` independent deep copies of `forked_session`, each safe to run
    exactly one `run_turn` against without any of them seeing another's
    turn. This is how U1 (5 question-form variants) and U2 (2 topic
    variants) get an identical starting state per the doc's requirement
    ("state must be identical for all five... do not run them sequentially").
    """
    snap = snapshot(forked_session)
    return [restore(snap) for _ in range(n)]
