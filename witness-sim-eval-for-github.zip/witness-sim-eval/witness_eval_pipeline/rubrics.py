"""
Every test's ANNOTATE schema from the Eval Plan doc, transcribed as data.

The doc was written for a human annotator reading a transcript with a pen.
Fields it originally defined by giving a literal example-phrase list (hedge
count, formulaic phrases) are instead defined here as a FUNCTIONAL CATEGORY
with those phrases kept only as illustrations — an LLM judge should count
utterances that serve the same hedging/deflecting function even when worded
differently, not literally string-match "to my knowledge" etc. That's the
whole point of automating this with a judge instead of a naive counter.

judge_prompts.py turns these definitions into actual Claude system prompts.
tests/*.py wire a specific test's question sequence to the right rubric.
"""

FUNCTIONAL_HEDGE_NOTE = (
    "A hedge is any utterance that weakens commitment to a claim without "
    "rejecting it outright — qualifying, softening, or distancing language. "
    "Illustrative examples the source protocol used (NOT an exhaustive or "
    "literal list — judge the function, not these exact words): "
    "\"to my knowledge,\" \"I don't recall,\" \"I'm not sure,\" \"I believe,\" "
    "\"as far as I know,\" \"I'd have to check,\" \"not necessarily,\" "
    "\"generally speaking.\" Recognize equivalent hedges phrased differently "
    "(e.g. \"I couldn't tell you for certain,\" \"it's possible, I suppose,\" "
    "\"that's not something I'd swear to\")."
)

FORMULAIC_PHRASE_NOTE = (
    "A formulaic/rehearsed phrase is corporate or scripted-sounding language "
    "that reads as prepared rather than spontaneous (e.g. \"our commitment to "
    "responsible distribution,\" \"consistent with regulatory requirements\") "
    "— judge by register and polish, not by matching a fixed phrase list."
)

# ── U1. Question Form Battery ────────────────────────────────────────────────
U1 = {
    "name": "U1. Question Form Battery",
    "scope": "5 independent single-turn injections (open/closed/leading/high-pressure/clarifying), identical starting state",
    "fields": [
        {"name": "direct_answer", "type": "scale", "min": 0, "max": 2,
         "levels": {2: "yes, directly answers", 1: "partially, some deflection", 0: "does not answer the question"}},
        {"name": "framing_acceptance", "type": "scale", "min": 0, "max": 2, "na_if": "condition not in {leading, high_pressure}",
         "levels": {2: "accepts the framing, agrees with the premise", 1: "partially accepts, qualifies without rejecting",
                    0: "explicitly rejects the framing or premise"}},
        {"name": "hedge_count", "type": "count", "note": FUNCTIONAL_HEDGE_NOTE},
        {"name": "pushback", "type": "scale", "min": 0, "max": 2,
         "levels": {0: "no pushback", 1: "mild pushback, quibbles with wording", 2: "explicit challenge to framing or premise"}},
        {"name": "tone", "type": "scale", "min": 0, "max": 2,
         "levels": {2: "cooperative, helpful", 1: "neutral, professional", 0: "guarded, resistant"}},
    ],
    "evaluate": {
        "universal": "open word count > closed yes/no word count",
        "archetype": [
            "framing_acceptance on leading question: combative/dogmatic < cooperative/neutral",
            "pushback highest in combative/dogmatic/overconfident",
            "hedge_count highest in nervous/defensive/evasive",
        ],
        "pass_rule": "universal holds AND at least 2 of 3 archetype criteria hold",
    },
}

# ── U2. Sensitive Topic Matched-Pair Test ────────────────────────────────────
U2 = {
    "name": "U2. Sensitive Topic Matched-Pair Test",
    "scope": "2 independent single-turn injections (sensitive vs. neutral-matched), cold start (turn 1, state s0) — no warm-up",
    "fields": [
        {"name": "hedge_count", "type": "count", "note": FUNCTIONAL_HEDGE_NOTE},
        {"name": "direct_answer", "type": "scale", "min": 0, "max": 2,
         "levels": {2: "gives a direct, specific answer", 1: "partial answer, some evasion", 0: "does not substantively answer"}},
        {"name": "specificity", "type": "scale", "min": 0, "max": 3,
         "levels": {3: "names specific people, dates, procedures, systems", 2: "gives general description of process",
                    1: "vague, non-committal description", 0: "no substantive content"}},
        {"name": "memory_claim_count", "type": "count",
         "note": "count claims of inability to recall (e.g. \"I don't recall X\") — functional, any phrasing"},
        {"name": "over_explanation", "type": "scale", "min": 0, "max": 2,
         "levels": {0: "answers proportionally", 1: "some over-explanation", 2: "extensive over-explanation, circles the topic"}},
    ],
    "evaluate": {
        "per_archetype_criteria": [
            "sensitivity(sensitive) > sensitivity(neutral)",
            "K(sensitive) < K(neutral)",
            "hedge_count(sensitive) > hedge_count(neutral)",
            "direct_answer(sensitive) < direct_answer(neutral)",
            "memory_claim_count(sensitive) > memory_claim_count(neutral)",
        ],
        "pass_rule": "at least 3 of 5 criteria hold for at least 7 of 10(+1) archetypes",
    },
}

# ── U3. Pressure-Recovery Arc Test ───────────────────────────────────────────
U3 = {
    "name": "U3. Pressure-Recovery Arc Test",
    "scope": "15-turn fixed sequence in 4 blocks: Baseline(1-3) / Pressure(4-8) / Recovery(9-12) / Re-escalation(13-15). Run as one continuous sequence, do not break apart.",
    "fields": [
        {"name": "hedge_count", "type": "count", "note": FUNCTIONAL_HEDGE_NOTE},
        {"name": "direct_answer", "type": "scale", "min": 0, "max": 2,
         "levels": {2: "yes, directly answers", 1: "partially, some deflection", 0: "does not answer the question"}},
        {"name": "tone", "type": "scale", "min": 0, "max": 2,
         "levels": {2: "cooperative, helpful", 1: "neutral, professional", 0: "guarded, resistant"}},
    ],
    "evaluate": {
        "block_level": [
            "C(pressure block) < C(baseline block)",
            "hedge_count(pressure) > hedge_count(baseline)",
            "direct_answer(pressure) < direct_answer(baseline)",
            "C(recovery) > C(pressure)",
            "re-escalation shows faster C drop than initial pressure block",
        ],
        "archetype": [
            "WITNESS RATTLED fires in pressure block for nervous/defensive",
            "combative/dogmatic show less C drop than nervous/defensive",
        ],
        "pass_rule": "first three block-level criteria hold AND recovery is partial (not a full reset to baseline)",
    },
}

# ── U4. Contradiction / Impeachment Response Test ────────────────────────────
U4 = {
    "name": "U4. Contradiction / Impeachment Response Test",
    "scope": "5-turn fixed sequence; turn 4's exact wording branches on the witness's actual turn-1 answer",
    "fields": [
        {"name": "turn1_position", "type": "label_set",
         "labels": ["never_flagged", "sometimes_flagged", "yes_flagged", "unclear_hedged"]},
        {"name": "response_category", "type": "label_set", "single_select": True,
         "labels": {
             "PUSHBACK": "directly challenges the attorney's framing, document validity, or premise",
             "RECONCILE": "attempts to explain how both things can be true",
             "DEFLECT": "changes subject, introduces irrelevant detail, claims memory failure",
             "CAPITULATE": "abandons prior answer and agrees with attorney's version",
             "NARROW_EXPLANATION": "explains only the specific aspect that protects self/company",
         }},
        {"name": "acknowledges_inconsistency", "type": "scale", "min": 0, "max": 2,
         "levels": {2: "yes, directly addresses it", 1: "implicitly acknowledges, dances around it", 0: "ignores it entirely"}},
        {"name": "tone_turn4", "type": "scale", "min": 0, "max": 2,
         "levels": {2: "calm", 1: "slightly tense", 0: "hostile or aggressive"}},
        {"name": "position_maintenance_turn5", "type": "scale", "min": 0, "max": 2,
         "levels": {2: "fully holds turn 4 position", 1: "softens, qualifies", 0: "reverses entirely"}},
    ],
    "pre_registered_predictions": {
        "Combative": {"turn4": "PUSHBACK", "turn5": "Holds"},
        "Dogmatic": {"turn4": "PUSHBACK", "turn5": "Holds"},
        "Overconfident": {"turn4": "PUSHBACK (dismissive)", "turn5": "Holds"},
        "Cooperative": {"turn4": "RECONCILE", "turn5": "Softens slightly"},
        "Defensive": {"turn4": "NARROW_EXPLANATION", "turn5": "Partial hold"},
        "Evasive": {"turn4": "DEFLECT (memory failure)", "turn5": "Partial hold"},
        "Nervous": {"turn4": "CAPITULATE", "turn5": "Reverses or overcorrects"},
        "Loquacious": {"turn4": "RECONCILE (elaborated)", "turn5": "Softens"},
        "Inventive": {"turn4": "creative reframe", "turn5": "Partial hold"},
        "Neutral": {"turn4": "RECONCILE (factual)", "turn5": "Softens"},
    },
    "evaluate": {
        "state_prediction_checks": [
            "high R predicts holding",
            "low A predicts pushback/hostility",
            "low K predicts memory uncertainty",
            "low C predicts rattled capitulation",
        ],
        "pass_rule": "response_category matches pre-registered prediction AND at least 2 of 4 state variables (R,A,K,C) correctly predict the observed category",
    },
}

# ── T1. Evasive Pin-Down Test ─────────────────────────────────────────────────
T1 = {
    "name": "T1. Evasive Pin-Down Test",
    "scope": "5-turn fixed sequence narrowing to a binary yes/no demand on turn 5. Primary archetypes: Evasive, Defensive, Nervous. Control: Cooperative, Neutral.",
    "fields": [
        {"name": "labels", "type": "label_set", "multi_select": True,
         "labels": {
             "DIRECT_ANSWER": "clearly answers what was asked",
             "HEDGE": "uses a qualifying phrase", "QUIBBLE": "disputes the wording or scope of the question",
             "DEFINITION_REQUEST": "asks the attorney to define a term",
             "NONRESPONSIVE": "talks around the question without answering",
             "PIN_DOWN_AVOIDANCE": "on turn 5 only — fails to give yes or no despite being asked",
         }},
        {"name": "hedge_count", "type": "count", "note": FUNCTIONAL_HEDGE_NOTE},
        {"name": "turn5_binary_compliance", "type": "label_set",
         "labels": ["YES", "PARTIAL", "NO", "CHALLENGED"]},
    ],
    "evaluate": {
        "primary_pass": "pin-down avoidance rate on turns 3-5 > 0.5 AND no clean yes/no on turn 5",
        "control_pass": "pin-down avoidance rate on turns 3-5 < 0.33 AND clean or partial yes/no on turn 5",
        "pass_rule": "primary archetypes show more pin-down avoidance than controls across at least 30 of 43 witnesses",
    },
}

# ── T2. Runaway Witness / Rabbit Trail Test ──────────────────────────────────
T2 = {
    "name": "T2. Runaway Witness / Rabbit Trail Test",
    "scope": "4-turn fixed sequence: open invite -> narrow -> restate constraint -> explicit yes/no. Primary: Loquacious, Inventive, Evasive. Control: Neutral, Cooperative.",
    "fields": [
        {"name": "turn1_label", "type": "label_set",
         "labels": ["RESPONSIVE", "RABBIT_TRAIL", "NONRESPONSIVE", "EMBELLISHMENT"]},
        {"name": "compliance_with_narrowing", "type": "scale", "min": 0, "max": 2,
         "levels": {2: "immediately narrows to the specific question", 1: "partially narrows but adds unrequested content",
                    0: "does not narrow, continues prior narrative"}},
        {"name": "turn4_binary", "type": "label_set", "labels": ["YES", "PARTIAL", "NO", "CHALLENGED"]},
    ],
    "evaluate": {
        "primary_pass": "turn 1 word count in top third for this witness AND compliance score on turn 2 in {0,1} AND no clean yes/no on turn 4",
        "control_pass": "compliance score on turn 2 = 2 AND binary yes/no on turn 4",
        "pass_rule": "primary archetypes show more nonresponsive narrative than controls AND narrowing changes the response pattern differently across primary vs. control",
    },
}

# ── T3. Hostile Witness Control Test ─────────────────────────────────────────
T3 = {
    "name": "T3. Hostile Witness Control Test",
    "scope": "5-turn fixed sequence (broad accusatory -> access -> inaction -> two one-fact narrows). Primary: Combative, Dogmatic, Overconfident. Control: Cooperative, Neutral.",
    "fields": [
        {"name": "labels", "type": "label_set", "multi_select": True,
         "labels": {
             "PUSHBACK": "directly challenges the attorney's framing or premise",
             "PREMISE_CHALLENGE": "disputes the factual basis of the question",
             "AGGRESSIVE_TONE": "hostile, confrontational, or dismissive language",
             "CONTROLLED_YES_NO": "gives clean binary answer to a one-fact question",
             "COMPLIANCE": "answers the question without resistance",
         }},
        {"name": "tone", "type": "scale", "min": 0, "max": 2,
         "levels": {2: "calm and cooperative", 1: "slightly resistant or guarded", 0: "hostile, challenging, or aggressive"}},
    ],
    "evaluate": {
        "key_distinction": "combative should be MORE aggressive in tone than dogmatic (distinguishes low-A hostility from high-R rigidity)",
        "primary_pass": "pushback appears in turns 1-3 AND tone score <= 1 AND at least one of {WITNESS COMBATIVE event, A decrease, R increase}",
        "control_pass": "no pushback OR no premise challenge, AND compliance with one-fact questions on turns 4-5",
        "pass_rule": "primary archetypes show more resistance than controls AND combative/dogmatic are distinguishable by tone",
    },
}

# ── T4. Fragile Memory / Refreshing Recollection Test ────────────────────────
T4 = {
    "name": "T4. Fragile Memory / Refreshing Recollection Test",
    "scope": "4-turn fixed sequence: memory probe -> specific detail -> document refresh (real exhibit) -> post-refresh probe. Primary: Nervous, Defensive, Evasive. Control: Cooperative, Overprepared.",
    "fields": [
        {"name": "no_recall_count", "type": "count", "note": "count instances functionally equivalent to \"I don't recall\"/\"I have no memory of\", any phrasing"},
        {"name": "memory_claim_type", "type": "label_set", "multi_select": True,
         "labels": ["COMPLETE_NON_RECALL", "PARTIAL_RECALL", "QUALIFIED_RECALL", "CLEAR_RECALL"]},
        {"name": "direct_answer", "type": "scale", "min": 0, "max": 2,
         "levels": {2: "directly answers with specific information", 1: "partial answer, uncertain", 0: "no substantive answer"}},
        {"name": "post_refresh_improvement", "type": "scale", "min": 0, "max": 2, "na_if": "turn in {1,2}",
         "levels": {2: "becomes more specific after seeing exhibit", 1: "partial improvement", 0: "no change or continued evasion"},
         "no_improvement_reason": ["continues_non_recall", "disputes_exhibit_relevance", "acknowledges_document_no_personal_recollection"]},
    ],
    "evaluate": {
        "key_distinction_forgetful_vs_evasive": "for nervous/cooperative: post-exhibit direct_answer > pre-exhibit; for evasive: post-exhibit direct_answer <= pre-exhibit",
        "primary_pass": {
            "Nervous": "high pre-exhibit non-recall AND improvement post-exhibit",
            "Evasive": "high pre-exhibit non-recall AND no improvement post-exhibit",
            "Defensive": "qualified recall pre-exhibit AND narrow acknowledgment post-exhibit",
        },
        "control_pass": {
            "Cooperative": "some uncertainty pre-exhibit AND improvement post-exhibit",
            "Overprepared": "low non-recall pre-exhibit AND more precise post-exhibit",
        },
        "pass_rule": "nervous and evasive show meaningfully different post-refresh behavior across at least 30 of 43 witnesses",
    },
}

# ── T5. Rigidity Under Friendly Off-Ramp Test ────────────────────────────────
T5 = {
    "name": "T5. Rigidity Under Friendly Off-Ramp Test",
    "scope": "5-turn fixed sequence; turn 4 is an explicitly LOW-PRESSURE friendly off-ramp (verify p_t < 0.3). Primary: Dogmatic, Overconfident, Combative. Control: Cooperative, Nervous.",
    "fields": [
        {"name": "turn1_position", "type": "label_set", "labels": ["claims_no_alerts", "claims_yes_some_alerts", "uncertain_hedged"]},
        {"name": "turn4_classification", "type": "label_set", "single_select": True,
         "labels": {
             "HOLDS_CALMLY": "maintains prior answer, neutral/polite tone",
             "HOLDS_DISMISSIVELY": "maintains prior answer, slightly dismissive",
             "HOLDS_WITH_EDGE": "maintains prior answer, resistant or slightly aggressive tone",
             "SOFTENS": "revises or qualifies the prior answer",
             "SOFTENS_EAGERLY": "enthusiastically accepts the off-ramp, over-qualifies",
             "DEFLECTS": "neither holds nor softens, changes subject",
         }},
        {"name": "tone_of_holding", "type": "scale", "min": 0, "max": 2,
         "levels": {2: "calm, polite", 1: "neutral", 0: "edged, resistant, aggressive"}},
        {"name": "turn5_final_position", "type": "scale", "min": 0, "max": 2,
         "levels": {2: "maintains same position as turn 4", 1: "partially softens from turn 4", 0: "fully reverses turn 4 position"}},
    ],
    "evaluate": {
        "critical_distinction": "dogmatic must be classified HOLDS_CALMLY (not HOLDS_WITH_EDGE); combative must be classified HOLDS_WITH_EDGE (not HOLDS_CALMLY) — this is what separates rigidity (R) from hostility (A)",
        "primary_pass": {
            "Dogmatic": "holds calmly (not with edge)",
            "Overconfident": "holds (calmly or dismissively)",
            "Combative": "holds with edge (not calmly)",
        },
        "control_pass": {"Cooperative": "softens or revises on turn 4", "Nervous": "softens eagerly or over-qualifies on turn 4"},
        "state_checks": [
            "high R predicts holding: R > 0.6 AND witness held",
            "low A predicts edged tone: A < 0.4 AND tone score == 0",
            "low C predicts eager softening: C < 0.4 AND nervous over-qualifies",
        ],
        "pass_rule": "primary archetypes hold more than controls AND dogmatic/combative are distinguishable by tone",
    },
}

# ── T6. Overprepared / Fatigue Degradation Test ──────────────────────────────
T6 = {
    "name": "T6. Overprepared / Fatigue Degradation Test",
    "scope": "30-turn moderate-pressure deposition; only turns 5, 15, 25 (identical extraction question) are scored. Primary: Overprepared. Control: Neutral, Cooperative.",
    "fields": [
        {"name": "rehearsedness", "type": "scale", "min": 0, "max": 3,
         "levels": {3: "highly rehearsed: corporate phrases, smooth, clearly prepared", 2: "polished: well-organized, professional, no obvious improvisation",
                    1: "mixed: partially rehearsed but shows some improvisation", 0: "improvised: unpolished, disorganized, searching for words"}},
        {"name": "specificity", "type": "scale", "min": 0, "max": 3,
         "levels": {3: "names specific policies, people, systems, dates", 2: "describes specific processes in general terms",
                    1: "vague, general description only", 0: "no substantive content"}},
        {"name": "formulaic_phrases", "type": "list", "note": FORMULAIC_PHRASE_NOTE},
        {"name": "consistency_with_turn5", "type": "scale", "min": 0, "max": 2, "na_if": "turn == 5",
         "levels": {2: "fully consistent with turn 5 answer", 1: "mostly consistent, minor differences",
                    0: "contradicts or significantly diverges from turn 5"}},
    ],
    "evaluate": {
        "overprepared_pass": [
            "rehearsedness declines from turn 5 to turn 25",
            "specificity declines or stays flat (does not increase)",
            "consistency degrades at turn 25 (score < 2)",
            "P value declines from turn 5 to turn 25",
        ],
        "control_pass": "rehearsedness stays within 1 point of the turn-5 value across all extraction points (flat trajectory)",
        "pass_rule": "overprepared archetype shows monotonic decline across all four overprepared_pass criteria AND control archetypes show a flatter trajectory",
    },
}

ALL_TESTS = {"U1": U1, "U2": U2, "U3": U3, "U4": U4, "T1": T1, "T2": T2, "T3": T3, "T4": T4, "T5": T5, "T6": T6}

# The 11 archetypes actually referenced across every test's primary/control
# tables (union of every archetype named in T1-T6 + U1's archetype criteria).
# The doc's own U-test header says "10 archetypes" (echoing the paper's
# narrower 10-archetype set, which excludes Evasive) but T1/T2/T4 all
# require Evasive as a primary archetype — so the doc's own content needs
# 11, not 10. Using the doc's actual requirement, not its header text.
ARCHETYPES_IN_SCOPE = [
    "Combative", "Cooperative", "Defensive", "Dogmatic", "Evasive",
    "Inventive", "Loquacious", "Neutral", "Nervous", "Overconfident", "Overprepared",
]
